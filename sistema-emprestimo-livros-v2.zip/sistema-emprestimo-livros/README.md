# 📚 Sistema de Empréstimo de Livros

Projeto da disciplina **Software Product: Analysis, Specification, Project & Implementation** (ADS).

Sistema web simples para controlar o empréstimo de livros de uma biblioteca.

## Perfis de acesso

| Perfil | O que pode fazer |
|--------|------------------|
| **Visitante** (sem login) | Consultar, buscar, filtrar e ordenar o acervo; cadastrar-se |
| **Usuário** (entra com a matrícula) | Tudo do visitante + emprestar livros, ver "Meus empréstimos" e renovar |
| **Bibliotecário** (entra com PIN) | Registrar devoluções, ver empréstimos em andamento, histórico completo (com exportação CSV), cadastrar/remover livros e usuários |

O PIN de demonstração do bibliotecário é **1234**. As permissões são verificadas dentro da classe `Biblioteca`, e não apenas escondendo botões. Atenção: como o sistema roda só no navegador, esse PIN **não é segurança real** (quem lê o código vê o PIN). Num sistema de verdade o login ficaria em um servidor.

## Funcionalidades

- **Cadastro com matrícula automática:** o usuário digita só o nome e o sistema gera a matrícula (ex.: `20260001`)
- **Catálogo de 40 livros** (romances populares no BookTok, fantasia, distopia, suspense e clássicos)
- **Login por matrícula** (usuário) e **por PIN** (bibliotecário), com sessão salva
- Cadastrar e remover **livros** (com gênero)
- **Busca** de livros por título ou autor, com **ordenação** (título, autor, gênero, disponíveis primeiro)
- **Filtros** por gênero e por disponibilidade (combináveis com a busca)
- **Capas reais** dos livros (buscadas na Open Library; sem internet aparece uma capa colorida)
- **Histórico de empréstimos:** quem pegou cada livro, quando retirou e quando devolveu, com busca e filtro por situação
- Realizar **empréstimo** (prazo de 7 dias) e **renovar** (+7 dias, até 2 vezes)
- **Multa** de R$ 1,00 por dia de atraso
- **Exportar o histórico em CSV** (bibliotecário)
- Registrar **devolução**
- Identificar empréstimos **atrasados**, com a quantidade de dias de atraso
- Botão **Simular atraso** (somente para demonstração) que vence o prazo de um empréstimo
- **Avisos na tela** (toast) após cada ação e **confirmação em dois cliques** antes de remover livros e usuários

## Novidades desta versão

- **Busca por significado:** o leitor descreve o que quer ("recomeços e superação, mas não muito longo") e o sistema identifica temas, gênero, tamanho e disponibilidade, justificando cada resultado
- **Recomendações com justificativa:** algoritmo próprio de pontuação ponderada (temas em comum, autor, série, gênero, preferências), ex.: "Você gostou de Correr ou Morrer. Talvez goste de Silo, porque ambos exploram sociedades isoladas, mistério e sobrevivência." Com dados suficientes, ativa filtragem colaborativa ("quem leu X também leu Y"). Não depende de IA paga
- **Lia, assistente de leitura:** responde perguntas consultando os dados reais (disponibilidade por gênero, prazos, reservas, por onde começar um gênero); nunca inventa informações
- **Acervo de 48 livros** com temas, páginas, sinopse, série, formatos acessíveis e **vários exemplares por título**, cada um com código próprio (ex.: BIB-0015-1)
- Código pronto para as próximas etapas (pasta `js/`): gerador de **QR Code** próprio (validado), reservas com fila, inventário, Biblioteca Circular (doação/troca), comunidade, painel de inteligência de dados e mapa de conhecimento

## Regras de negócio

- A matrícula é gerada automaticamente e é única (ano + número sequencial)
- Um livro emprestado não pode ser emprestado novamente
- Cada usuário pode ter no máximo **3 empréstimos ativos**
- Cada empréstimo pode ser **renovado até 2 vezes**, e só se não estiver atrasado
- Não é permitido cadastrar o mesmo livro (mesmo título e autor) duas vezes
- Usuário com **livro atrasado fica bloqueado** de pegar novos livros até devolver
- Não é possível remover livro emprestado nem usuário com empréstimo ativo

## Tecnologias

HTML, CSS e JavaScript (classes ES6). Os dados ficam salvos no `localStorage` do navegador. As capas vêm da API pública da [Open Library](https://openlibrary.org/) (precisa de internet só para buscar as capas; o resto do sistema funciona offline).

## Como executar

Não precisa instalar nada. Baixe o projeto e abra o arquivo `index.html` no navegador (mantenha `app.js` e `style.css` na mesma pasta).

Alternativa: o arquivo `biblioteca-completo.html` tem tudo embutido (HTML, CSS e JavaScript) e funciona sozinho, mesmo copiado para outro lugar.

## Banco de dados

Os dados (livros, usuários, empréstimos, contador de matrículas e versão do acervo) ficam salvos no **localStorage** do navegador, que funciona como um pequeno banco de dados local. O acervo inicial é carregado automaticamente na primeira abertura.

## Documentação

- [Diagrama de classes](docs/diagrama-classes.puml) (PlantUML) e [versão Mermaid](docs/diagramas-mermaid.md)
- [Diagrama de caso de uso](docs/caso-de-uso.puml) (PlantUML)
- [Diagrama de sequência](docs/diagrama-sequencia-emprestimo.puml) e [diagrama de estados](docs/diagrama-estados-emprestimo.puml) do empréstimo
- Imagens prontas dos diagramas em [docs/imagens](docs/imagens)
- [Backlog, critérios de aceite e cronograma de 6 meses](docs/backlog-board.md)
- [Plano de testes](docs/plano-de-testes.md)
- Board do projeto: _(cole aqui o link do seu board)_

## Autor

_(seu nome e RA)_
