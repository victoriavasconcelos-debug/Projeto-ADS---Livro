// ===================== INTERFACE =====================

const biblioteca = new Biblioteca();
const $ = id => document.getElementById(id);

function esc(texto) {
  const d = document.createElement("div");
  d.textContent = texto;
  return d.innerHTML.replace(/"/g, "&quot;");
}

// Aviso flutuante no topo da tela (visível de qualquer ponto da página)
let timerToast = null;
function mensagem(texto, erro = false) {
  const el = $("toast");
  el.textContent = texto;
  el.className = "toast " + (erro ? "toast-erro" : "toast-ok") + " visivel";
  clearTimeout(timerToast);
  timerToast = setTimeout(() => el.classList.remove("visivel"), 3500);
}

// Remoção em dois cliques: o primeiro pede confirmação, o segundo remove.
// (Não usa confirm() porque alguns previews bloqueiam essa janela.)
let confirmacaoPendente = null;
let timerConfirmacao = null;
function confirmarEExecutar(chave, acao, sucesso) {
  clearTimeout(timerConfirmacao);
  if (confirmacaoPendente === chave) {
    confirmacaoPendente = null;
    executar(acao, sucesso);
    return;
  }
  confirmacaoPendente = chave;
  timerConfirmacao = setTimeout(() => { confirmacaoPendente = null; render(); }, 4000);
  mensagem("Clique em Confirmar para remover.");
  render();
}

function executar(acao, sucesso) {
  try {
    acao();
    if (sucesso) mensagem(sucesso);
  } catch (e) {
    mensagem(e.message, true);
  }
  render();
}

function formatarMoeda(valor) {
  return valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatarData(iso) {
  return new Date(iso).toLocaleDateString("pt-BR");
}

function formatarDataHora(iso) {
  return new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

// Cor da capa de reserva a partir do título (sempre a mesma para o mesmo livro)
function corCapa(titulo) {
  let h = 0;
  for (const c of titulo) h = (h * 31 + c.charCodeAt(0)) % 360;
  return `linear-gradient(145deg, hsl(${h}, 55%, 42%), hsl(${(h + 40) % 360}, 60%, 32%))`;
}

// ---------- Capas reais (Open Library) ----------
// A capa é buscada online uma vez e o endereço fica guardado no navegador.
// Sem internet (ou sem capa encontrada), continua aparecendo a capa colorida.

const API_BUSCA_CAPAS = "https://openlibrary.org/search.json";

async function buscarCapaOnline(livro) {
  const params = new URLSearchParams({
    title: livro.tituloOriginal || livro.titulo,
    author: livro.autor,
    limit: "5",
    fields: "cover_i"
  });
  const resposta = await fetch(`${API_BUSCA_CAPAS}?${params}`);
  if (!resposta.ok) throw new Error("Busca de capas indisponível.");
  const dados = await resposta.json();
  const achado = (dados.docs || []).find(d => d.cover_i);
  return achado ? `https://covers.openlibrary.org/b/id/${achado.cover_i}-M.jpg` : "";
}

const capasTentadas = new Set();
let carregandoCapas = false;

async function carregarCapas() {
  if (carregandoCapas || typeof fetch !== "function") return;
  carregandoCapas = true;
  let livro;
  while ((livro = biblioteca.livros.find(l => l.capaUrl === null && !capasTentadas.has(l.id)))) {
    capasTentadas.add(livro.id);
    try {
      livro.capaUrl = await buscarCapaOnline(livro);
      biblioteca.salvar();
      render();
    } catch (e) { /* sem internet: tenta de novo na próxima vez que abrir */ }
  }
  carregandoCapas = false;
}

// Chamada quando a imagem da capa não carrega: volta para a capa colorida
function capaFalhou(id) {
  const livro = biblioteca.livros.find(l => l.id === id);
  if (!livro) return;
  livro.capaUrl = "";
  biblioteca.salvar();
  render();
}

// ---------- Ações da tela ----------

// Histórico filtrado por um livro específico (botão "Histórico" no card, só bibliotecário)
let histLivroId = null;

// Matrícula recém-gerada, mostrada em destaque até o usuário clicar em "Entendi"
let novaMatricula = null;

function emprestarLivro(livroId) {
  const usuarioId = biblioteca.sessao ? biblioteca.sessao.usuarioId : null;
  executar(() => biblioteca.emprestar(livroId, usuarioId), "Empréstimo realizado! Devolução em 7 dias.");
}

function verHistorico(livroId) {
  histLivroId = livroId;
  $("hist-busca").value = "";
  $("hist-situacao").value = "";
  render();
  $("sec-historico").scrollIntoView({ behavior: "smooth" });
}

function limparHistLivro() {
  histLivroId = null;
  render();
}

function limparFiltrosCatalogo() {
  $("busca").value = "";
  $("filtro-genero").value = "";
  $("filtro-situacao").value = "";
  $("ordenar").value = "";
  render();
}

function fecharBoasVindas() {
  novaMatricula = null;
  render();
}

// Mostra só o que o perfil atual pode usar: <section data-perfil="usuario bibliotecario"> etc.
function aplicarPerfil() {
  const perfil = biblioteca.perfil;
  document.querySelectorAll("[data-perfil]").forEach(el => {
    el.hidden = !el.dataset.perfil.split(" ").includes(perfil);
  });
}

function renderSessao() {
  const perfil = biblioteca.perfil;
  const usuario = biblioteca.usuarioLogado;
  const caixa = $("boas-vindas");
  if (perfil === "usuario" && usuario) {
    $("sessao-info").innerHTML = `👤 Olá, <b>${esc(usuario.nome)}</b> · matrícula <b>${esc(usuario.matricula)}</b>`;
  } else if (perfil === "bibliotecario") {
    $("sessao-info").innerHTML = `🛡️ Modo <b>bibliotecário</b>`;
  }
  if (perfil === "usuario" && usuario && novaMatricula === usuario.matricula) {
    caixa.innerHTML = `Cadastro concluído, <b>${esc(usuario.nome)}</b>! Sua matrícula é <strong>${esc(usuario.matricula)}</strong>
      <span class="sub-aviso">Anote o número: você vai precisar dele para entrar de novo.</span>
      <button class="pequeno secundario" onclick="fecharBoasVindas()">Entendi</button>`;
    caixa.hidden = false;
  } else {
    caixa.hidden = true;
  }
}

// Painel de números no topo da página
function atualizarEstatisticas() {
  const total = biblioteca.livros.length;
  const disponiveis = biblioteca.livros.filter(l => l.disponivel).length;
  const atrasos = biblioteca.emprestimos.filter(e => e.atrasado).length;
  $("stats").innerHTML = `
    <div class="stat"><strong>${disponiveis}</strong><span>Disponíveis</span></div>
    <div class="stat"><strong>${total - disponiveis}</strong><span>Emprestados</span></div>
    <div class="stat ${atrasos ? "alerta" : ""}"><strong>${atrasos}</strong><span>Atrasos</span></div>`;
}

// Aviso para o usuário logado que está bloqueado por atraso
function atualizarAvisoEmprestimo() {
  const aviso = $("aviso-emprestimo");
  const usuario = biblioteca.usuarioLogado;
  const atrasados = usuario ? biblioteca.emprestimos.filter(e => e.usuarioId === usuario.id && e.atrasado).length : 0;
  if (atrasados) {
    aviso.textContent = `⚠ Você tem ${atrasados} livro(s) atrasado(s) e está bloqueado(a) de pegar novos livros até devolver. Procure o bibliotecário.`;
    aviso.hidden = false;
  } else {
    aviso.hidden = true;
  }
}

function situacaoHtml(e) {
  if (e.ativo) {
    return e.atrasado
      ? `<span class="atrasado">Atrasado (${e.diasAtraso} dia${e.diasAtraso > 1 ? "s" : ""})</span><span class="sub">Multa: ${formatarMoeda(e.multa)}</span>`
      : `<span class="ocupado">Em andamento</span>`;
  }
  return e.devolvidoComAtraso
    ? `<span class="atrasado">Devolvido com atraso</span><span class="sub">Multa: ${formatarMoeda(e.multa)}</span>`
    : `<span class="ok">Devolvido</span>`;
}

// Prazo com a marca de renovações (ex.: "28/11/2026 · renovado 1x")
function prazoHtml(e) {
  return formatarData(e.dataPrevista) + (e.renovacoes ? `<span class="sub">renovado ${e.renovacoes}x</span>` : "");
}

// O card muda conforme o perfil:
// visitante só olha | usuário pode emprestar | bibliotecário vê histórico e remove
function cardLivro(l) {
  const perfil = biblioteca.perfil;
  const emp = biblioteca.emprestimoAtivoDe(l.id);
  const pendente = confirmacaoPendente === "livro-" + l.id;
  const bloqueado = perfil === "usuario" && biblioteca.possuiAtraso(biblioteca.sessao.usuarioId);

  const imagem = l.capaUrl
    ? `<img src="${esc(l.capaUrl)}" alt="Capa de ${esc(l.titulo)}" loading="lazy" referrerpolicy="no-referrer" onerror="capaFalhou(${l.id})">`
    : "";

  let quem = "";
  if (emp) {
    quem = perfil === "bibliotecario"
      ? `Com ${esc(biblioteca.nomeDe(emp))} · devolver até ${formatarData(emp.dataPrevista)}`
      : `Previsão de devolução: ${formatarData(emp.dataPrevista)}`;
  }

  let acoes = "";
  if (perfil === "usuario" && l.disponivel) {
    acoes = `<button class="pequeno emprestar" ${bloqueado ? 'disabled title="Você tem livro atrasado"' : ""} onclick="emprestarLivro(${l.id})">Emprestar</button>`;
  } else if (perfil === "bibliotecario") {
    acoes = `
      <button class="pequeno secundario" title="Quem pegou este livro e quando devolveu" onclick="verHistorico(${l.id})">Histórico</button>
      <button class="pequeno remover ${pendente ? "perigo" : "fantasma"}" title="Remover do acervo" onclick="confirmarEExecutar('livro-${l.id}', () => biblioteca.removerLivro(${l.id}), 'Livro removido.')">${pendente ? "Confirmar" : "✕"}</button>`;
  }

  return `
    <div class="livro ${l.disponivel ? "" : "indisponivel"}">
      <div class="capa" style="background:${corCapa(l.titulo)}"><span class="capa-titulo">${esc(l.titulo)}</span>${imagem}</div>
      <div class="livro-info">
        <span class="livro-autor">${esc(l.autor)}</span>
        <span class="livro-genero">${esc(l.genero || "Outros")}</span>
        <span class="selo ${l.disponivel ? "disp" : "emp"}">${l.disponivel ? "Disponível" : "Emprestado"}</span>
        ${quem ? `<span class="livro-quem">${quem}</span>` : ""}
        ${acoes ? `<div class="livro-acoes">${acoes}</div>` : ""}
      </div>
    </div>`;
}

function render() {
  const perfil = biblioteca.perfil;
  aplicarPerfil();
  renderSessao();

  // Acervo (com busca e filtros) - todos podem ver
  const lista = biblioteca.buscarLivros({
    texto: $("busca").value,
    genero: $("filtro-genero").value,
    situacao: $("filtro-situacao").value,
    ordem: $("ordenar").value
  });
  $("contagem").textContent = biblioteca.livros.length
    ? `Mostrando ${lista.length} de ${biblioteca.livros.length} livros`
    : "";
  $("catalogo").innerHTML = lista.length
    ? lista.map(cardLivro).join("")
    : `<p class="vazio">${biblioteca.livros.length ? "Nenhum livro encontrado com esses filtros." : "Nenhum livro cadastrado."}</p>`;

  atualizarAvisoEmprestimo();
  atualizarEstatisticas();

  // Área do usuário: só os próprios empréstimos
  if (perfil === "usuario") {
    const meus = biblioteca.historico();
    const andamento = meus.filter(e => e.ativo).length;
    const multaTotal = meus.reduce((soma, e) => soma + e.multa, 0);
    $("meus-resumo").textContent = meus.length
      ? `Você tem ${andamento} livro(s) em andamento (limite de ${MAX_EMPRESTIMOS}).` +
        (multaTotal ? ` Multas acumuladas: ${formatarMoeda(multaTotal)}.` : "")
      : "";
    $("lista-meus").innerHTML = meus.length
      ? meus.map(e => `
        <tr>
          <td>${esc(biblioteca.tituloDe(e))}</td>
          <td>${formatarDataHora(e.dataEmprestimo)}</td>
          <td>${prazoHtml(e)}</td>
          <td>${e.ativo ? "—" : formatarDataHora(e.dataDevolucao)}</td>
          <td>${situacaoHtml(e)}</td>
          <td>${e.ativo && !e.atrasado
            ? (e.renovacoes < MAX_RENOVACOES
                ? `<button class="pequeno secundario" onclick="executar(() => biblioteca.renovar(${e.id}), 'Empréstimo renovado por mais ${PRAZO_DIAS} dias!')">Renovar</button>`
                : `<span class="sub">limite de renovações</span>`)
            : ""}</td>
        </tr>`).join("")
      : `<tr><td colspan="6" class="vazio">Você ainda não pegou nenhum livro. Escolha um no acervo e clique em Emprestar.</td></tr>`;
  }

  // Área do bibliotecário: usuários, empréstimos em andamento e histórico completo
  if (perfil === "bibliotecario") {
    $("lista-usuarios").innerHTML = biblioteca.usuarios.length
      ? biblioteca.usuarios.map(u => `
        <tr>
          <td><strong>${esc(u.matricula || "-")}</strong></td><td>${esc(u.nome)}</td>
          <td><button class="perigo pequeno" onclick="confirmarEExecutar('usuario-${u.id}', () => biblioteca.removerUsuario(${u.id}), 'Usuário removido.')">${confirmacaoPendente === "usuario-" + u.id ? "Confirmar?" : "Remover"}</button></td>
        </tr>`).join("")
      : `<tr><td colspan="3" class="vazio">Nenhum usuário cadastrado.</td></tr>`;

    const ativos = biblioteca.historico().filter(e => e.ativo);
    $("lista-emprestimos").innerHTML = ativos.length
      ? ativos.map(e => `
        <tr>
          <td>${esc(biblioteca.tituloDe(e))}</td>
          <td>${esc(biblioteca.nomeDe(e))}<span class="sub">${esc(biblioteca.matriculaDe(e))}</span></td>
          <td>${formatarData(e.dataEmprestimo)}</td>
          <td>${prazoHtml(e)}</td>
          <td>${situacaoHtml(e)}</td>
          <td>
            <button class="pequeno" onclick="executar(() => biblioteca.devolver(${e.id}), 'Livro devolvido!')">Devolver</button>
            ${e.atrasado ? "" : `<button class="pequeno secundario" title="Só para demonstração" onclick="executar(() => biblioteca.simularAtraso(${e.id}), 'Prazo vencido (simulação).')">⏰ Simular atraso</button>`}
          </td>
        </tr>`).join("")
      : `<tr><td colspan="6" class="vazio">Nenhum empréstimo em andamento.</td></tr>`;

    const historico = biblioteca.historico({
      livroId: histLivroId,
      texto: $("hist-busca").value,
      situacao: $("hist-situacao").value
    });
    const chip = $("hist-chip");
    if (histLivroId !== null) {
      const livro = biblioteca.livros.find(l => l.id === histLivroId);
      const titulo = livro ? livro.titulo : (historico[0] ? biblioteca.tituloDe(historico[0]) : "livro removido");
      chip.innerHTML = `Mostrando só o histórico de <b>${esc(titulo)}</b> <button class="pequeno secundario" onclick="limparHistLivro()">Ver todos</button>`;
      chip.hidden = false;
    } else {
      chip.hidden = true;
    }
    $("hist-contagem").textContent = biblioteca.emprestimos.length
      ? `${historico.length} registro(s) encontrado(s)`
      : "";
    $("lista-historico").innerHTML = historico.length
      ? historico.map(e => `
        <tr>
          <td>${esc(biblioteca.tituloDe(e))}</td>
          <td>${esc(biblioteca.nomeDe(e))}<span class="sub">${esc(biblioteca.matriculaDe(e))}</span></td>
          <td>${formatarDataHora(e.dataEmprestimo)}</td>
          <td>${prazoHtml(e)}</td>
          <td>${e.ativo ? "—" : formatarDataHora(e.dataDevolucao)}</td>
          <td>${situacaoHtml(e)}</td>
        </tr>`).join("")
      : `<tr><td colspan="6" class="vazio">${biblioteca.emprestimos.length ? "Nenhum registro com esses filtros." : "Ainda não há empréstimos."}</td></tr>`;
  }
}

// ---------- Formulários ----------

// Os botões usam "click" (e Enter nos campos) em vez de enviar o formulário,
// assim funciona também em previews que bloqueiam o envio de formulários.
function ligarFormulario(formId, acao) {
  const form = $(formId);
  form.addEventListener("submit", ev => ev.preventDefault());
  form.querySelector("button").addEventListener("click", acao);
  form.querySelectorAll("input").forEach(campo => {
    campo.addEventListener("keydown", ev => {
      if (ev.key === "Enter") { ev.preventDefault(); acao(); }
    });
  });
}

function acaoLoginUsuario() {
  executar(() => {
    const usuario = biblioteca.entrarComoUsuario($("login-matricula").value);
    $("login-matricula").value = "";
    mensagem(`Bem-vindo(a), ${usuario.nome}!`);
  });
}

function acaoCadastrarUsuario() {
  executar(() => {
    const usuario = biblioteca.cadastrarUsuario($("usuario-nome").value.trim());
    biblioteca.entrarComoUsuario(usuario.matricula); // depois de se cadastrar, já entra
    novaMatricula = usuario.matricula;
    $("usuario-nome").value = "";
    mensagem("Cadastro feito! Matrícula: " + usuario.matricula);
  });
}

function acaoLoginBibliotecario() {
  executar(() => {
    biblioteca.entrarComoBibliotecario($("login-pin").value);
    $("login-pin").value = "";
    mensagem("Bem-vindo(a), bibliotecário(a)!");
  });
}

function acaoExportarCsv() {
  try {
    const csv = biblioteca.exportarHistoricoCsv({
      livroId: histLivroId,
      texto: $("hist-busca").value,
      situacao: $("hist-situacao").value
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "historico-emprestimos.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 1000);
    mensagem("Histórico exportado (historico-emprestimos.csv).");
  } catch (e) {
    mensagem(e.message, true);
  }
}

function acaoSair() {
  biblioteca.sair();
  novaMatricula = null;
  histLivroId = null;
  confirmacaoPendente = null;
  $("hist-busca").value = "";
  $("hist-situacao").value = "";
  mensagem("Você saiu do sistema.");
  render();
}

function acaoCadastrarLivro() {
  executar(() => {
    biblioteca.cadastrarLivro($("livro-titulo").value.trim(), $("livro-autor").value.trim(), $("livro-genero").value);
    $("livro-titulo").value = "";
    $("livro-autor").value = "";
    mensagem("Livro cadastrado!");
  });
  carregarCapas();
}

// ---------- Inicialização ----------

function montarSelectsDeGenero() {
  $("filtro-genero").innerHTML = `<option value="">Todos os gêneros</option>` +
    GENEROS.map(g => `<option value="${esc(g)}">${esc(g)}</option>`).join("");
  $("livro-genero").innerHTML = GENEROS.map(g => `<option value="${esc(g)}">${esc(g)}</option>`).join("");
  $("livro-genero").value = "Romance";
}

montarSelectsDeGenero();

$("busca").addEventListener("input", render);
$("filtro-genero").addEventListener("change", render);
$("filtro-situacao").addEventListener("change", render);
$("ordenar").addEventListener("change", render);
$("btn-exportar").addEventListener("click", acaoExportarCsv);
$("limpar-filtros").addEventListener("click", limparFiltrosCatalogo);
$("hist-busca").addEventListener("input", () => { histLivroId = null; render(); });
$("hist-situacao").addEventListener("change", render);
$("btn-sair").addEventListener("click", acaoSair);
ligarFormulario("form-login-usuario", acaoLoginUsuario);
ligarFormulario("form-usuario", acaoCadastrarUsuario);
ligarFormulario("form-login-bib", acaoLoginBibliotecario);
ligarFormulario("form-livro", acaoCadastrarLivro);

render();
carregarCapas();
