# Roteiro do vídeo (4 a 6 minutos)

Grave a tela com OBS Studio, Xbox Game Bar (Windows + G), ou Zoom/Meet (compartilhar tela e gravar). Fale com calma.
Antes de gravar, limpe os dados do site (F12 → Application → Local Storage → apagar) e atualize a página.

## 1. Abertura (20s)
"Olá, meu nome é ___, RA ___. Este é meu trabalho de Software Product. Desenvolvi um sistema de empréstimo de livros com dois perfis: usuário e bibliotecário."

## 2. Visitante e acervo (50s) — abra o index.html
1. Mostre a tela de entrada e diga: "Sem entrar, a pessoa só consulta o acervo." Note que não há botões nos livros.
2. Busque "hoover", escolha o gênero "Drama", depois "Só emprestados" e use a ordenação (por exemplo, "Título (A–Z)"). Clique em "Limpar filtros". Mostre as capas e que o acervo tem 40 livros.

## 3. Perfil USUÁRIO (1 min 30s)
1. Digite seu nome em "Gerar minha matrícula". Mostre a matrícula (ex.: 20260001) e a barra "Olá, ___".
2. Clique em "Emprestar" em um livro. Mostre o aviso e a área "Meus empréstimos".
3. Clique em "Renovar" e mostre "renovado 1x" e o prazo aumentando 7 dias.
4. Clique em "Sair". Mostre que voltou a ser visitante. Entre de novo digitando a matrícula.

## 4. Perfil BIBLIOTECÁRIO (1 min 30s)
1. Clique em "Sair", digite o PIN 1234 e entre como bibliotecário. Mostre que agora aparecem Usuários cadastrados, Empréstimos em andamento, Histórico e Cadastrar livro, e que o botão Emprestar sumiu.
2. Em "Empréstimos em andamento", clique em "⏰ Simular atraso" (explique que é só para demonstração) e mostre "Atrasado (1 dia)" com a multa de R$ 1,00.
3. Saia e entre como o usuário: mostre o aviso vermelho, os botões Emprestar desabilitados, a multa em "Meus empréstimos" e que o botão Renovar sumiu.
4. Volte como bibliotecário e clique em Devolver. Mostre o histórico ("Devolvido com atraso" com a multa) e clique em "Histórico" no card de um livro e depois "Ver todos". Mostre "Exportar histórico (CSV)".
5. Tente remover um livro emprestado (✕ e depois Confirmar) e mostre a mensagem de erro.
6. Atualize a página (F5) e mostre que os dados continuam lá.

## 5. Diagramas (1 min)
- Casos de uso: "O visitante consulta o acervo e se cadastra. O usuário entra, empresta, renova e consulta seus empréstimos. O bibliotecário entra com PIN, registra devoluções, consulta empréstimos e histórico e gerencia acervo e usuários."
- Classes: "Livro, Usuario, Emprestimo e Sessao, gerenciados pela classe Biblioteca. As permissões por perfil ficam dentro da Biblioteca."
- Se quiser, mostre também o diagrama de sequência do empréstimo e o de estados do empréstimo.

## 6. Board e GitHub (30s)
- Mostre o board com as histórias de usuário, colunas e o cronograma.
- Mostre o repositório no GitHub com o código-fonte e o README.

## 7. Encerramento (10s)
"Esse foi o meu projeto. Obrigado!"

## Dicas
- O PIN do bibliotecário (1234) é de demonstração: como o sistema roda só no navegador, ele não é segurança real. Se o professor perguntar, explique que num sistema real o login ficaria em um servidor.
- Deixe o zoom do navegador em 110% a 125% para ficar legível.
- Ensaie uma vez antes de gravar.
