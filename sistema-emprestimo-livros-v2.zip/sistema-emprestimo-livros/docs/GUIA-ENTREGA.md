# Guia de entrega (passo a passo)

## 1. Diagramas → imagens
1. Acesse https://www.plantuml.com/plantuml/uml
2. Cole o conteúdo de `docs/caso-de-uso.puml` e baixe o PNG.
3. Repita com `docs/diagrama-classes.puml` (e, se quiser, `diagrama-sequencia-emprestimo.puml` e `diagrama-estados-emprestimo.puml`).
4. Salve as imagens como `caso-de-uso.png` e `diagrama-classes.png` (use na apresentação).

Alternativa: abra `docs/diagramas-mermaid.md` no GitHub, que já renderiza os 4 desenhos. As imagens prontas estão em `docs/imagens/`.

## 2. GitHub
1. Crie conta em https://github.com (se não tiver) e clique em **New repository**.
2. Nome: `sistema-emprestimo-livros`. Marque **Public**. Clique em Create.
3. Clique em **uploading an existing file** e arraste TODOS os arquivos e a pasta `docs` (descompactados).
4. Clique em **Commit changes**.
5. Copie o link do repositório (ex.: https://github.com/seu-usuario/sistema-emprestimo-livros).

## 3. Board
**Trello:** crie um quadro, adicione as colunas Backlog / Em andamento / Em revisão / Concluído e crie os cartões de `docs/backlog-board.md`. Em Compartilhar, deixe o link visível para quem tem o link.

**GitHub Projects (alternativa):** no repositório, aba Projects → New project → Board, e adicione os cartões.

Copie o link do board.

## 4. Vídeo
Siga `docs/roteiro-video.md`. Envie para o YouTube como **Não listado** (ou Google Drive com acesso por link) e copie o link.

## 5. Classroom
Entregue no Classroom:
- Link do vídeo
- Link do board
- Link do GitHub
- Diagramas (imagens ou PDF, e prepare-se para apresentá-los)

## 6. Antes de enviar, confira
- [ ] README com seu nome e RA
- [ ] Link do board colado no README
- [ ] Repositório público e abrindo sem login
- [ ] Vídeo abrindo em aba anônima
- [ ] Todos os links no Classroom
