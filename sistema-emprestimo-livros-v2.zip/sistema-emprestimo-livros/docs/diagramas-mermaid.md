# Diagramas (versão Mermaid)

O GitHub renderiza estes diagramas automaticamente ao abrir este arquivo.
Versões em PlantUML (UML padrão): `caso-de-uso.puml`, `diagrama-classes.puml`, `diagrama-sequencia-emprestimo.puml` e `diagrama-estados-emprestimo.puml`.

## 1. Diagrama de classes

```mermaid
classDiagram
    class Perfil {
        <<enumeration>>
        VISITANTE
        USUARIO
        BIBLIOTECARIO
    }
    class Livro {
        -int id
        -String titulo
        -String autor
        -String genero
        -String tituloOriginal
        -String capaUrl
        -boolean disponivel
    }
    class Usuario {
        -int id
        -String nome
        -String matricula
    }
    class Sessao {
        -Perfil perfil
        -int usuarioId
    }
    class Emprestimo {
        -int id
        -int livroId
        -int usuarioId
        -String livroTitulo
        -String usuarioNome
        -String usuarioMatricula
        -Date dataEmprestimo
        -Date dataPrevista
        -Date dataDevolucao
        -int renovacoes
        +ativo() boolean
        +atrasado() boolean
        +diasAtraso() int
        +devolvidoComAtraso() boolean
        +multa() double
    }
    class Biblioteca {
        -Livro[] livros
        -Usuario[] usuarios
        -Emprestimo[] emprestimos
        -Sessao sessao
        -int contadorMatricula
        -Map contadores
        -int acervoVersao
        +perfil() Perfil
        +entrarComoUsuario(matricula) Usuario
        +entrarComoBibliotecario(pin) void
        +sair() void
        -exigirBibliotecario(acao) void
        +carregarAcervoInicial() void
        +gerarMatricula() String
        +cadastrarUsuario(nome) Usuario
        +cadastrarLivro(titulo, autor, genero) Livro
        +removerLivro(id) void
        +removerUsuario(id) void
        +buscarLivros(texto, genero, situacao, ordem) Livro[]
        +possuiAtraso(usuarioId) boolean
        +emprestar(livroId, usuarioId) Emprestimo
        +renovar(emprestimoId) Emprestimo
        +devolver(emprestimoId) void
        +simularAtraso(emprestimoId) void
        +emprestimoAtivoDe(livroId) Emprestimo
        +historico(livroId, usuarioId, texto, situacao) Emprestimo[]
        +exportarHistoricoCsv(filtros) String
        +salvar() void
        +carregar() boolean
        +completarAcervo() void
    }
    Biblioteca "1" o-- "0..*" Livro : gerencia
    Biblioteca "1" o-- "0..*" Usuario : gerencia
    Biblioteca "1" o-- "0..*" Emprestimo : registra
    Biblioteca "1" --> "0..1" Sessao : sessão atual
    Sessao --> Perfil
    Sessao "0..*" --> "0..1" Usuario : usuário logado
    Emprestimo "0..*" --> "1" Livro : refere-se a
    Emprestimo "0..*" --> "1" Usuario : realizado por
```

## 2. Casos de uso (aproximação em Mermaid)

O Mermaid não tem diagrama de caso de uso oficial, então este é um fluxograma equivalente. O arquivo `caso-de-uso.puml` (PlantUML) é a versão em UML padrão. Usuário e Bibliotecário também podem fazer tudo o que o Visitante faz (UC01 e UC02).

```mermaid
flowchart LR
    Vis(["👤 Visitante (sem login)"])
    Usu(["👤 Usuário"])
    Bib(["👤 Bibliotecário"])
    Usu -. é um .-> Vis
    Bib -. é um .-> Vis

    Vis --> UC01([UC01 Cadastrar-se])
    Vis --> UC02([UC02 Buscar, filtrar e ordenar livros])

    Usu --> UC11([UC11 Entrar no sistema])
    Bib --> UC11

    Usu --> UC03([UC03 Realizar empréstimo])
    Usu --> UC12([UC12 Consultar meus empréstimos])
    Usu --> UC13([UC13 Renovar empréstimo])

    Bib --> UC04([UC04 Registrar devolução])
    Bib --> UC05([UC05 Consultar empréstimos em andamento])
    Bib --> UC10([UC10 Consultar histórico])
    Bib --> UC07([UC07 Cadastrar livro])
    Bib --> UC08([UC08 Remover livro])
    Bib --> UC09([UC09 Remover usuário])

    UC01 -. include .-> UCM([Gerar matrícula única])
    UC03 -. include .-> UCV([Validar disponibilidade, limite de 3 e ausência de atraso])
    UC13 -. include .-> UCR([Validar renovação: máx. 2 e sem atraso])
    UC05 -. include .-> UC06([UC06 Verificar atrasos])
    UC06 -. include .-> UC14([UC14 Calcular multa])
    UC04 -. include .-> UC14
    UC15([UC15 Exportar histórico CSV]) -. extend .-> UC10
```

## 3. Diagrama de sequência: realizar empréstimo

```mermaid
sequenceDiagram
    actor U as Usuário
    participant UI as Interface
    participant B as Biblioteca
    participant L as Livro
    participant E as Emprestimo
    participant DB as localStorage
    U->>UI: clica em "Emprestar"
    UI->>B: emprestar(livroId, usuarioId)
    B->>B: confere perfil e usuário da sessão
    B->>B: possuiAtraso(usuarioId)?
    alt usuário com livro atrasado
        B-->>UI: erro "Empréstimo bloqueado"
    else livro indisponível
        B-->>UI: erro "Livro já emprestado"
    else já tem 3 empréstimos ativos
        B-->>UI: erro "Limite de 3"
    else regras satisfeitas
        B->>E: new Emprestimo (prazo de 7 dias)
        B->>L: disponivel = false
        B->>DB: salvar()
        B-->>UI: Emprestimo
        UI-->>U: aviso "Empréstimo realizado!"
    end
```

## 4. Diagrama de estados: empréstimo

```mermaid
stateDiagram-v2
    [*] --> EmAndamento : emprestar()
    EmAndamento --> EmAndamento : renovar() +7 dias (máx. 2, sem atraso)
    EmAndamento --> Atrasado : prazo vence
    Atrasado --> Atrasado : multa de R$ 1,00 por dia
    EmAndamento --> Devolvido : devolver()
    Atrasado --> DevolvidoComAtraso : devolver() registra a multa
    Devolvido --> [*]
    DevolvidoComAtraso --> [*]
```
