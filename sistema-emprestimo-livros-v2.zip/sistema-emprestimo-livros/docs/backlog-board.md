# Backlog para o Board (Trello / GitHub Projects)

Crie 4 colunas: **Backlog | Em andamento | Em revisão | Concluído**
Como o sistema já está pronto, deixe a maioria dos cartões em **Concluído** e 1 ou 2 em Backlog (melhorias futuras).

## Histórias de usuário

| ID | História | Prioridade | Coluna sugerida |
|----|----------|-----------|-----------------|
| HU01 | Como usuário, quero me cadastrar digitando só meu nome e receber uma matrícula automática | Alta | Concluído |
| HU02 | Como usuário, quero ver o catálogo de livros disponíveis para escolher o que ler | Alta | Concluído |
| HU03 | Como usuário, quero pegar um livro emprestado por 7 dias | Alta | Concluído |
| HU04 | Como bibliotecário, quero registrar a devolução para liberar o livro | Alta | Concluído |
| HU05 | Como bibliotecário, quero ver quais empréstimos estão atrasados | Média | Concluído |
| HU06 | Como bibliotecário, quero cadastrar livros para manter o acervo atualizado | Média | Concluído |
| HU07 | Como bibliotecário, quero remover livros que saíram do acervo | Baixa | Concluído |
| HU08 | Como bibliotecário, quero remover usuários inativos | Baixa | Concluído |
| HU09 | Como usuário, quero que meus dados fiquem salvos ao fechar o navegador | Média | Concluído |
| HU10 | Como bibliotecário, quero ver avisos claros na tela após cada ação (sucesso ou erro) | Média | Concluído |
| HU11 | Como bibliotecário, quero confirmar antes de remover um livro ou usuário para evitar exclusões acidentais | Média | Concluído |
| HU12 | Como bibliotecário, quero ver há quantos dias um empréstimo está atrasado | Média | Concluído |
| HU13 | Como bibliotecário, quero bloquear novos empréstimos de quem está com livro atrasado para incentivar a devolução | Alta | Concluído |
| HU14 | Como usuário, quero um site com visual moderno e fácil de usar, inclusive no celular | Média | Concluído |
| HU15 | Como usuário, quero buscar livros por título ou autor para achar rápido o que quero ler | Alta | Concluído |
| HU16 | Como usuário, quero filtrar os livros por gênero e por disponibilidade | Alta | Concluído |
| HU17 | Como bibliotecário, quero consultar quem pegou cada livro e quando devolveu | Alta | Concluído |
| HU18 | Como usuário, quero ver a capa real dos livros para reconhecê-los mais fácil | Média | Concluído |
| HU19 | Como usuário, quero entrar no sistema com a minha matrícula para acessar minha área | Alta | Concluído |
| HU20 | Como bibliotecário, quero entrar com um PIN para acessar as funções de gestão | Alta | Concluído |
| HU21 | Como bibliotecário, quero que usuários e visitantes não consigam cadastrar/remover livros, devolver ou ver o histórico geral (separação de perfis) | Alta | Concluído |
| HU22 | Como usuário, quero ver somente os meus empréstimos, com prazo e situação | Alta | Concluído |
| HU23 | Como usuário, quero renovar um empréstimo (+7 dias, até 2 vezes) se ele não estiver atrasado | Média | Concluído |
| HU24 | Como bibliotecário, quero que o atraso gere multa de R$ 1,00 por dia, visível para mim e para o usuário | Média | Concluído |
| HU25 | Como usuário, quero ordenar o acervo por título, autor, gênero ou disponibilidade | Baixa | Concluído |
| HU26 | Como bibliotecário, quero exportar o histórico em CSV para abrir no Excel | Baixa | Concluído |
| HU27 | Como usuário, quero um acervo maior (40 livros) para ter mais opções de leitura | Média | Concluído |
| HU28 | Como bibliotecário, quero evitar livros duplicados e nomes de usuário inválidos | Baixa | Concluído |

## Tarefas técnicas

- Levantar requisitos e regras de negócio → Concluído
- Modelar diagrama de casos de uso → Concluído
- Modelar diagrama de classes → Concluído
- Criar classes Livro, Usuario, Emprestimo e Biblioteca → Concluído
- Implementar geração automática de matrícula → Concluído
- Montar acervo inicial com romances do BookTok → Concluído
- Criar interface com catálogo em cards (HTML/CSS) → Concluído
- Implementar persistência com localStorage → Concluído
- Criar aviso flutuante (toast) para feedback das ações → Concluído
- Criar confirmação em dois cliques para remoções → Concluído
- Criar simulação de atraso para demonstração e cálculo de dias de atraso → Concluído
- Implementar bloqueio de novos empréstimos para usuário com atraso (regra e aviso na tela) → Concluído
- Redesenhar a interface (estilo moderno, painel de números, layout responsivo) → Concluído
- Implementar busca por título/autor (sem diferenciar acentos e maiúsculas) → Concluído
- Implementar gênero nos livros e filtros por gênero e disponibilidade → Concluído
- Criar seção de histórico com filtros e histórico por livro → Concluído
- Guardar nome e matrícula no empréstimo e não reutilizar ids, para o histórico não se perder → Concluído
- Buscar capas reais na Open Library, com capa colorida de reserva sem internet → Concluído
- Migrar dados salvos por versões antigas (gênero, capa e nomes no histórico) → Concluído
- Implementar perfis (visitante, usuário, bibliotecário), login por matrícula/PIN e sessão salva → Concluído
- Aplicar permissões dentro da classe Biblioteca (não só esconder botões na tela) → Concluído
- Criar área "Meus empréstimos" e renovação de empréstimo → Concluído
- Implementar multa por atraso e exibir no histórico e no CSV → Concluído
- Implementar ordenação e exportação de CSV → Concluído
- Ampliar acervo para 40 livros e migrar dados de quem já usava o sistema (versão do acervo) → Concluído
- Validar regras (livro já emprestado, limite de 3, remoção bloqueada) → Concluído
- Atualizar diagramas (casos de uso, classes, sequência e estados) → Concluído
- Testes automatizados de navegador (ver `plano-de-testes.md`) → Concluído
- Gravar vídeo de demonstração → Concluído
- Subir código no GitHub → Concluído

## Ideias futuras (deixe em Backlog)

- Login com senha de verdade e back-end (hoje o PIN roda só no navegador)
- Banco de dados real (MER) no lugar do localStorage
- Reserva de livros que estão emprestados
- Notificações de prazo por e-mail
- Pagamento/baixa de multa
- Relatórios (livros mais emprestados, usuários com mais atrasos)

## Critérios de aceite (exemplos)

- **HU01:** ao digitar o nome e confirmar, o sistema mostra a matrícula gerada (ano + número sequencial) e ela nunca se repete.
- **HU02:** o catálogo mostra título, autor e status (Disponível/Emprestado) de cada livro.
- **HU03:** ao emprestar, o livro muda para "Emprestado" e some da lista de livros disponíveis.
- **HU04:** ao devolver, o livro volta para "Disponível" e a data de devolução é registrada.
- **HU11:** ao clicar para remover, o botão vira "Confirmar"; só o segundo clique remove, e a confirmação expira em 4 segundos.
- **HU12:** um empréstimo com prazo vencido aparece como "Atrasado (N dias)" na tabela.
- **HU13:** se o usuário tem livro atrasado, a tela mostra um aviso, o botão Emprestar fica desabilitado e o sistema recusa o empréstimo; ao devolver o livro, ele é liberado.
- **HU15:** ao digitar no campo de busca, a lista mostra só os livros cujo título ou autor contém o texto (ex.: "selecao" encontra "A Seleção").
- **HU16:** os filtros de gênero e de disponibilidade podem ser combinados entre si e com a busca; o sistema mostra "Mostrando X de Y livros".
- **HU17:** o histórico lista cada empréstimo com livro, usuário (nome e matrícula), data de retirada, prazo, data de devolução e situação; o botão "Histórico" do livro mostra só os empréstimos dele.
- **HU18:** cada livro mostra a capa real quando ela é encontrada online; sem internet ou sem capa, aparece a capa colorida com o título.
- **HU19:** matrícula inexistente mostra erro e não entra; matrícula válida mostra o nome na barra de sessão; a sessão continua após atualizar a página.
- **HU20/HU21:** com PIN errado não entra; sem login só é possível consultar o acervo; chamadas diretas a `emprestar`, `devolver`, `cadastrarLivro`, etc. sem o perfil correto são recusadas com mensagem.
- **HU22:** cada usuário vê apenas os próprios empréstimos; o bibliotecário vê todos.
- **HU23:** renovar soma 7 dias ao prazo e mostra "renovado Nx"; na 3ª tentativa o sistema recusa; empréstimo atrasado não renova.
- **HU24:** empréstimo atrasado mostra "Multa: R$ X,XX" (dias de atraso x R$ 1,00); a multa fica gravada após a devolução.
- **HU26:** o botão exporta `historico-emprestimos.csv` respeitando a busca e o filtro do histórico.
- **Regra:** o sistema bloqueia o 4º empréstimo ativo de um mesmo usuário com mensagem de erro.

## Cronograma sugerido para um projeto de 6 meses

| Mês | Foco | Entregas |
|-----|------|----------|
| 1 | Levantamento de requisitos | Escopo, regras de negócio, histórias de usuário, board criado |
| 2 | Modelagem | Diagramas de casos de uso e de classes, protótipo das telas |
| 3 | Núcleo do sistema | Classes, cadastro com matrícula, acervo, empréstimo e devolução, persistência |
| 4 | Regras e perfis | Atraso, bloqueio, login por perfil, permissões, "Meus empréstimos" |
| 5 | Recursos avançados | Busca, filtros, ordenação, histórico, capas, renovação, multa, exportação CSV |
| 6 | Qualidade e entrega | Testes, correções, documentação, diagramas finais, vídeo, apresentação |

Cada mês pode virar uma sprint no board (ou duas sprints de 2 semanas), com as histórias acima distribuídas por prioridade.
