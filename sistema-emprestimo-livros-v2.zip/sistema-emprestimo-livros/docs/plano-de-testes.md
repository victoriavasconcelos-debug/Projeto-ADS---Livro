# Plano de testes

Os testes abaixo foram executados automaticamente em um navegador (Chrome controlado por script), em tela de computador e de celular, inclusive em visualização restrita (sem `localStorage`) e sem internet. Resultado da última execução: **todos aprovados**.

## Perfis e permissões
| # | Cenário | Resultado esperado |
|---|---------|--------------------|
| 1 | Visitante abre o site | Vê a tela de entrada e o acervo sem botões; não vê "Meus empréstimos", usuários, em andamento, histórico nem cadastro de livro |
| 2 | Visitante tenta chamar emprestar, cadastrarLivro, removerLivro, removerUsuario, devolver, simularAtraso, historico | Todas recusadas com mensagem |
| 3 | Matrícula inexistente, vazia e PIN errado | Não entra e mostra aviso |
| 4 | Cadastro de usuário | Gera matrícula, entra logado e mostra o número em destaque |
| 5 | Usuário tenta emprestar em nome de outro, cadastrar/remover livro, devolver, simular atraso, renovar empréstimo de outro | Todas recusadas |
| 6 | Sessão após atualizar a página; sair; entrar de novo | Mantém, volta a visitante, entra com a matrícula |
| 7 | Bibliotecário (PIN 1234) | Vê usuários, em andamento, histórico, cadastro; não vê "Emprestar" nem "Meus empréstimos"; não consegue emprestar nem renovar |
| 8 | Segundo usuário | Não vê empréstimos do primeiro e não é bloqueado pelo atraso dele |

## Regras de negócio
| # | Cenário | Resultado esperado |
|---|---------|--------------------|
| 9 | Emprestar livro disponível | Livro vira "Emprestado" e aparece em "Meus empréstimos" |
| 10 | Livro emprestado | Outro usuário não consegue pegar; o card mostra só a previsão de devolução |
| 11 | Limite de 3 empréstimos ativos | O 4º é recusado |
| 12 | Usuário com atraso | Botões Emprestar desabilitados, aviso na tela e recusa no código |
| 13 | Renovar | +7 dias, "renovado 1x"; 2ª ok; 3ª recusada; atrasado não renova |
| 14 | Multa | R$ 1,00 por dia de atraso, mostrada na tabela e gravada após a devolução |
| 15 | Remover usuário com empréstimo ativo / livro emprestado | Recusado; sem empréstimo ativo, remove após confirmação em dois cliques |
| 16 | Cadastrar livro duplicado (ignora acento e maiúsculas) | Recusado |
| 17 | Nome de usuário com menos de 3 letras | Recusado |

## Acervo, busca e histórico
| # | Cenário | Resultado esperado |
|---|---------|--------------------|
| 18 | Busca por título/autor (sem diferenciar acento), filtros de gênero e disponibilidade, ordenação | Resultados corretos e combináveis; "Limpar filtros" zera tudo |
| 19 | Histórico (todos, por livro, busca, filtro de situação) | Registros corretos; nomes continuam mesmo se o usuário for removido |
| 20 | Exportar CSV | Arquivo com acentos corretos, separador `;`, multa e renovações; só o bibliotecário exporta |
| 21 | Capas reais | Aparecem quando encontradas; sem internet ou sem capa, capa colorida |
| 22 | Dados salvos por versões antigas | Abrem sem erro; livros novos do acervo são acrescentados uma única vez, sem trazer de volta livros removidos |
| 23 | Celular (390 px) e preview restrito | Sem rolagem lateral e sem erros |
