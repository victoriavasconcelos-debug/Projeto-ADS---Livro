// ===================== INTELIGÊNCIA DE DADOS =====================
// Indicadores para o bibliotecário tomar decisões sobre o acervo.

const LEITORES_POR_EXEMPLAR_MES = 4; // prazo de 7 dias → cerca de 4 leitores por exemplar a cada 30 dias
const DIAS_PARADO = 60;
const DIAS_SEMANA = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const PERIODOS_DIA = [
  { id: "manha", nome: "Manhã", de: 6, ate: 12 },
  { id: "tarde", nome: "Tarde", de: 12, ate: 18 },
  { id: "noite", nome: "Noite", de: 18, ate: 24 },
  { id: "madrugada", nome: "Madrugada", de: 0, ate: 6 }
];

const InteligenciaDados = {
  painel(bib, dias = 30) {
    bib.exigirBibliotecario("ver o painel de dados");
    const agora = new Date();
    const ini = new Date(agora - dias * DIA_MS);
    const iniAnterior = new Date(agora - 2 * dias * DIA_MS);
    const noPeriodo = d => new Date(d) >= ini && new Date(d) <= agora;
    const noAnterior = d => new Date(d) >= iniAnterior && new Date(d) < ini;

    const emp = bib.emprestimos.filter(e => noPeriodo(e.dataEmprestimo));
    const empAnt = bib.emprestimos.filter(e => noAnterior(e.dataEmprestimo));
    const reservasPeriodo = bib.reservas.filter(r => noPeriodo(r.data));

    // Taxa de atraso: entre empréstimos cujo prazo já venceu (devolvidos ou não) nos últimos 90 dias
    const vencidos = bib.emprestimos.filter(e => new Date(e.dataPrevista) < agora && new Date(e.dataEmprestimo) >= new Date(agora - 90 * DIA_MS));
    const comAtraso = vencidos.filter(e => e.atrasado || e.devolvidoComAtraso);
    const taxaAtraso = vencidos.length ? (comAtraso.length / vencidos.length) * 100 : 0;

    // Procura por título = empréstimos + reservas no período
    const procura = new Map();
    const somar = (id, campo) => {
      if (!procura.has(id)) procura.set(id, { emprestimos: 0, reservas: 0 });
      procura.get(id)[campo]++;
    };
    emp.forEach(e => somar(e.livroId, "emprestimos"));
    reservasPeriodo.forEach(r => somar(r.livroId, "reservas"));
    const maisProcurados = [...procura.entries()]
      .map(([id, v]) => ({ livro: bib.livros.find(l => l.id === id), ...v, total: v.emprestimos + v.reservas }))
      .filter(x => x.livro)
      .sort((a, b) => b.total - a.total)
      .slice(0, 6);

    // Tendência por gênero (período atual x anterior)
    const generoDe = e => (bib.livros.find(l => l.id === e.livroId) || {}).genero || "Outros";
    const generos = GENEROS.map(g => {
      const atual = emp.filter(e => generoDe(e) === g).length;
      const anterior = empAnt.filter(e => generoDe(e) === g).length;
      const variacao = anterior ? ((atual - anterior) / anterior) * 100 : (atual ? 100 : 0);
      return { genero: g, atual, anterior, variacao, perdendo: anterior >= 3 && variacao <= -30, crescendo: atual >= 3 && variacao >= 30 };
    }).filter(g => g.atual || g.anterior).sort((a, b) => b.atual - a.atual);

    // Quando os empréstimos acontecem
    const porDiaSemana = DIAS_SEMANA.map(() => 0);
    const porPeriodo = PERIODOS_DIA.map(p => ({ ...p, total: 0 }));
    emp.forEach(e => {
      const d = new Date(e.dataEmprestimo);
      porDiaSemana[d.getDay()]++;
      const h = d.getHours();
      const p = porPeriodo.find(x => h >= x.de && h < x.ate);
      if (p) p.total++;
    });

    // Livros parados (sem empréstimo há DIAS_PARADO dias)
    const ultimoEmprestimo = new Map();
    bib.emprestimos.forEach(e => {
      const t = new Date(e.dataEmprestimo).getTime();
      if (!ultimoEmprestimo.has(e.livroId) || ultimoEmprestimo.get(e.livroId) < t) ultimoEmprestimo.set(e.livroId, t);
    });
    const parados = bib.livros
      .filter(l => l.exemplaresAtivos.length && !l.emprestado)
      .map(l => {
        const ultimo = ultimoEmprestimo.get(l.id);
        const desde = ultimo || new Date(l.cadastradoEm || agora).getTime();
        return { livro: l, ultimo: ultimo ? new Date(ultimo) : null, dias: Math.floor((agora - desde) / DIA_MS) };
      })
      .filter(x => x.dias >= DIAS_PARADO || (!x.ultimo && bib.emprestimos.length > 20))
      .sort((a, b) => b.dias - a.dias);

    // Demanda não atendida: reservas no período x exemplares do título
    const demanda = bib.livros.map(l => {
      const reservas = reservasPeriodo.filter(r => r.livroId === l.id).length;
      const exemplares = l.exemplaresAtivos.length || 1;
      const fila = bib.filaDe(l.id).length;
      const porExemplar = reservas / exemplares;
      const sugestao = Math.ceil(reservas / LEITORES_POR_EXEMPLAR_MES);
      return { livro: l, reservas, exemplares, fila, porExemplar, sugestao };
    }).filter(d => d.reservas >= 3).sort((a, b) => b.porExemplar - a.porExemplar);

    const leitoresAtivos = new Set(emp.map(e => e.usuarioId)).size;
    const circular = bib.indicadoresCirculares();
    const atrasados = bib.emprestimos.filter(e => e.atrasado);

    const resultado = {
      dias, emprestimos: emp.length, emprestimosAnterior: empAnt.length, taxaAtraso, vencidos: vencidos.length,
      comAtraso: comAtraso.length, leitoresAtivos, reservas: reservasPeriodo.length, maisProcurados, generos,
      porDiaSemana, porPeriodo, parados, demanda, circular, atrasados,
      multasAbertas: atrasados.reduce((s, e) => s + e.multa, 0)
    };
    resultado.insights = this.insights(resultado);
    return resultado;
  },

  // Frases de apoio à decisão geradas a partir dos números
  insights(p) {
    const lista = [];
    const top = p.demanda[0];
    if (top && top.porExemplar >= 2) {
      lista.push({ tipo: "alerta", texto: `${top.livro.titulo} recebeu ${top.reservas} reservas em ${p.dias} dias e tem só ${top.exemplares} exemplar${top.exemplares > 1 ? "es" : ""}. Para atender essa procura, seriam necessários cerca de +${top.sugestao} exemplares.` });
    }
    const crescendo = p.generos.filter(g => g.crescendo).sort((a, b) => b.variacao - a.variacao)[0];
    if (crescendo) lista.push({ tipo: "ok", texto: `${crescendo.genero} está em alta: ${crescendo.atual} empréstimos, ${Math.round(crescendo.variacao)}% a mais que nos ${p.dias} dias anteriores.` });
    const caindo = p.generos.filter(g => g.perdendo).sort((a, b) => a.variacao - b.variacao)[0];
    if (caindo) lista.push({ tipo: "aviso", texto: `${caindo.genero} está perdendo interesse (${Math.round(caindo.variacao)}%). Uma vitrine temática ou clube de leitura pode ajudar.` });
    const pico = [...p.porPeriodo].sort((a, b) => b.total - a.total)[0];
    const diaPico = p.porDiaSemana.indexOf(Math.max(...p.porDiaSemana));
    if (pico && pico.total) lista.push({ tipo: "info", texto: `O pico de empréstimos é no período da ${pico.nome.toLowerCase()} e às ${["domingos", "segundas", "terças", "quartas", "quintas", "sextas", "sábados"][diaPico]}: bom horário para reforçar o balcão.` });
    if (p.parados.length) lista.push({ tipo: "info", texto: `${p.parados.length} título${p.parados.length > 1 ? "s estão parados" : " está parado"} há mais de ${DIAS_PARADO} dias. Vale divulgar ou repensar a reposição.` });
    if (p.taxaAtraso >= 15) lista.push({ tipo: "aviso", texto: `A taxa de atraso está em ${p.taxaAtraso.toFixed(0)}%. Lembretes antes do vencimento podem reduzir esse número.` });
    return lista;
  }
};
