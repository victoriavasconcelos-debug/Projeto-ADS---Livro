// ===================== NOVOS RECURSOS NA TELA =====================
// Busca por significado, recomendações com justificativa e a assistente Lia.

function miniLivro(l, motivo) {
  return `<div class="mini-livro"><div class="mini-capa" style="background:${corCapa(l.titulo)}">${esc(l.titulo)}</div>
    <div><b>${esc(l.titulo)}</b><span class="sub">${esc(l.autor)} · ${esc(l.genero)} · ${l.paginas || "?"} páginas · ${l.disponivel ? `${l.qtdDisponiveis} disponível(is)` : "emprestado"}</span>
    ${motivo ? `<p class="motivo">${esc(motivo)}</p>` : ""}</div></div>`;
}

function buscarSignificado() {
  const texto = $("sig-texto").value;
  const { interpretacao: i, resultados } = BuscaSemantica.buscar(biblioteca, texto, { limite: 6 });
  const partes = [];
  if (i.temas.length) partes.push("temas: " + juntarLista(i.temas));
  if (i.generos.length) partes.push("gênero: " + i.generos.join(", "));
  if (i.tamanho) partes.push(NOME_TAMANHO[i.tamanho]);
  if (i.disponivel) partes.push("só disponíveis");
  $("sig-interpretacao").textContent = partes.length ? "Entendi que você procura → " + partes.join(" · ") : "Não identifiquei temas; tente descrever assuntos, gênero ou tamanho.";
  $("sig-resultados").innerHTML = resultados.length
    ? resultados.map(r => miniLivro(r.livro, "Por quê: " + r.motivos.join(" · "))).join("")
    : `<p class="vazio">Nenhum livro encontrado.</p>`;
}

let lidosVisitante = [];
function renderRecomendacoes() {
  $("lista-titulos").innerHTML = biblioteca.livros.map(l => `<option value="${esc(l.titulo)}">`).join("");
  const perfil = perfilDeLeitura(biblioteca);
  lidosVisitante.forEach(id => perfil.lidos.add(id));
  $("lidos-chips").textContent = perfil.lidos.size
    ? "Já lidos: " + biblioteca.livros.filter(l => perfil.lidos.has(l.id)).map(l => l.titulo).join(", ")
    : "";
  const { resultados } = Recomendador.recomendar(biblioteca, perfil, 5);
  $("rec-resultados").innerHTML = perfil.lidos.size
    ? resultados.map(r => miniLivro(r.livro, r.motivo + (r.chips.length ? " (" + r.chips.join(", ") + ")" : ""))).join("")
    : `<p class="vazio">Adicione um livro que você já leu (ex.: Correr ou Morrer) para receber recomendações.</p>`;
}

function marcarLido() {
  const t = normalizar($("lido-titulo").value);
  const livro = biblioteca.livros.find(l => normalizar(l.titulo) === t);
  if (!livro) { mensagem("Escolha um título da lista.", true); return; }
  if (biblioteca.usuarioLogado) { if (!biblioteca.livrosLidosDe(biblioteca.usuarioLogado.id).has(livro.id)) biblioteca.alternarLido(livro.id); }
  else if (!lidosVisitante.includes(livro.id)) lidosVisitante.push(livro.id);
  $("lido-titulo").value = "";
  renderRecomendacoes();
}

function liaAdicionar(quem, html) {
  const el = document.createElement("div");
  el.className = "lia-msg " + quem;
  el.innerHTML = html;
  $("lia-msgs").appendChild(el);
  $("lia-msgs").scrollTop = $("lia-msgs").scrollHeight;
}

function perguntarLia(texto) {
  texto = String(texto || $("lia-pergunta").value).trim();
  if (!texto) return;
  $("lia-pergunta").value = "";
  liaAdicionar("eu", esc(texto));
  const r = Lia.responder(biblioteca, texto);
  let html = r.texto.map(t => `<p>${esc(t).replace(/\n/g, "<br>")}</p>`).join("");
  html += r.livros.map(x => `<div class="lia-livro">📖 <b>${esc(x.livro.titulo)}</b>${x.nota ? ` <span class="sub">${esc(x.nota)}</span>` : ""}</div>`).join("");
  if (r.fonte) html += `<span class="sub">Fonte: catálogo da biblioteca (tempo real)</span>`;
  html += (r.sugestoes || []).map(s => `<button type="button" class="pequeno secundario sug">${esc(s)}</button>`).join(" ");
  liaAdicionar("ela", html);
}

ligarFormulario("form-significado", buscarSignificado);
ligarFormulario("form-lido", marcarLido);
ligarFormulario("form-lia", () => perguntarLia());
$("btn-lia").addEventListener("click", () => {
  $("lia").hidden = !$("lia").hidden;
  if (!$("lia").hidden && !$("lia-msgs").children.length) perguntarLia("ajuda");
  if (!$("lia").hidden) $("lia-pergunta").focus();
});
$("lia-fechar").addEventListener("click", () => { $("lia").hidden = true; });
$("lia-msgs").addEventListener("click", ev => { if (ev.target.classList.contains("sug")) perguntarLia(ev.target.textContent); });

const renderOriginal = render;
render = function () { renderOriginal(); renderRecomendacoes(); };
render();
