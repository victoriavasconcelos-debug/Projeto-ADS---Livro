// ===================== MODELO DE DOMÍNIO =====================
// Classes do sistema e a classe Biblioteca, que concentra as regras de negócio
// e as permissões de cada perfil (visitante, usuário e bibliotecário).

// PIN de demonstração do bibliotecário.
// Atenção: como o sistema roda só no navegador, esse PIN NÃO é segurança de verdade
// (qualquer pessoa técnica consegue ver o código). Num sistema real, o login fica no servidor.
const PIN_BIBLIOTECARIO = "1234";

// Regras de empréstimo
const PRAZO_DIAS = 7;          // prazo de cada empréstimo (e de cada renovação)
const MAX_RENOVACOES = 2;      // quantas vezes um empréstimo pode ser renovado
const MAX_EMPRESTIMOS = 3;     // empréstimos ativos por usuário
const MAX_RESERVAS = 3;        // reservas ativas por usuário
const MULTA_POR_DIA = 1.0;     // R$ por dia de atraso
const ACERVO_VERSAO = 3;       // aumenta quando o acervo inicial ganha livros ou dados novos
const DIA_MS = 86400000;

// Estados possíveis de um exemplar físico
const ESTADOS_EXEMPLAR = {
  disponivel: "Disponível",
  emprestado: "Emprestado",
  danificado: "Danificado",
  perdido: "Perdido"
};

// Remove acentos e maiúsculas para a busca achar "seleçao" ao digitar "selecao"
function normalizar(texto) {
  return String(texto || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
}

function diasEntre(a, b) {
  return Math.floor((new Date(b) - new Date(a)) / DIA_MS);
}

// Um título pode ter vários exemplares físicos. Cada exemplar tem código próprio (usado no QR Code).
function codigoExemplar(livroId, numero) {
  return `BIB-${String(livroId).padStart(4, "0")}-${numero}`;
}

class Livro {
  constructor(id, titulo, autor, genero = "Outros", tituloOriginal = "") {
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.genero = genero;
    this.tituloOriginal = tituloOriginal; // usado só para achar a capa online
    this.paginas = 0;
    this.serie = "";
    this.temas = [];
    this.sinopse = "";
    this.formatos = ["impresso"];
    this.exemplares = [];   // [{ codigo, estado, origem, doacaoId, adicionadoEm }]
    this.capaUrl = null;    // null = ainda não buscou; "" = buscou e não achou
    this.origem = "acervo"; // "acervo" ou "doacao" (veio da Biblioteca Circular)
    this.cadastradoEm = new Date().toISOString();
  }

  // Exemplares que existem na prática (perdidos não contam)
  get exemplaresAtivos() {
    return this.exemplares.filter(x => x.estado !== "perdido");
  }

  get qtdDisponiveis() {
    return this.exemplares.filter(x => x.estado === "disponivel").length;
  }

  get disponivel() {
    return this.qtdDisponiveis > 0;
  }

  get emprestado() {
    return this.exemplares.some(x => x.estado === "emprestado");
  }

  adicionarExemplar(origem = "acervo", doacaoId = null) {
    const maior = this.exemplares.reduce((m, x) => Math.max(m, Number(x.codigo.split("-")[2]) || 0), 0);
    const ex = {
      codigo: codigoExemplar(this.id, maior + 1),
      estado: "disponivel",
      origem,
      doacaoId,
      adicionadoEm: new Date().toISOString()
    };
    this.exemplares.push(ex);
    return ex;
  }
}

class Usuario {
  constructor(id, nome, matricula) {
    this.id = id;
    this.nome = nome;
    this.matricula = matricula;
    this.lidos = [];            // livros que a pessoa já leu fora da biblioteca (ids)
    this.preferencias = null;   // { generos, temas, minutosPorDia, tamanho, series }
    this.metaMensal = 0;        // meta pessoal de livros por mês
    this.acessibilidade = null; // preferências de acessibilidade aplicadas ao entrar
    this.cadastradoEm = new Date().toISOString();
  }
}

class Emprestimo {
  // livroTitulo, usuarioNome e usuarioMatricula ficam guardados no empréstimo
  // para o histórico continuar correto mesmo se o livro ou usuário for removido.
  constructor(id, livroId, usuarioId, diasPrazo = 7, livroTitulo = "", usuarioNome = "", usuarioMatricula = "", exemplarCodigo = "") {
    this.id = id;
    this.livroId = livroId;
    this.usuarioId = usuarioId;
    this.livroTitulo = livroTitulo;
    this.usuarioNome = usuarioNome;
    this.usuarioMatricula = usuarioMatricula;
    this.exemplarCodigo = exemplarCodigo;
    this.dataEmprestimo = new Date().toISOString();
    const prazo = new Date();
    prazo.setDate(prazo.getDate() + diasPrazo);
    this.dataPrevista = prazo.toISOString();
    this.dataDevolucao = null;
    this.renovacoes = 0;
  }

  get ativo() {
    return this.dataDevolucao === null;
  }

  get atrasado() {
    return this.ativo && new Date() > new Date(this.dataPrevista);
  }

  get diasAtraso() {
    if (!this.atrasado) return 0;
    return Math.max(1, diasEntre(this.dataPrevista, new Date()));
  }

  get diasRestantes() {
    if (!this.ativo) return 0;
    return Math.ceil((new Date(this.dataPrevista) - new Date()) / DIA_MS);
  }

  get devolvidoComAtraso() {
    return !this.ativo && new Date(this.dataDevolucao) > new Date(this.dataPrevista);
  }

  get multa() {
    const fim = this.ativo ? new Date() : new Date(this.dataDevolucao);
    const prazo = new Date(this.dataPrevista);
    if (fim <= prazo) return 0;
    return Math.max(1, Math.floor((fim - prazo) / DIA_MS)) * MULTA_POR_DIA;
  }
}

// Fila de espera de um título sem exemplar disponível
class Reserva {
  constructor(id, livroId, usuarioId, usuarioNome = "", livroTitulo = "") {
    this.id = id;
    this.livroId = livroId;
    this.usuarioId = usuarioId;
    this.usuarioNome = usuarioNome;
    this.livroTitulo = livroTitulo;
    this.data = new Date().toISOString();
    this.status = "ativa"; // ativa | atendida | cancelada | expirada
    this.dataFim = null;
  }
}

// Livro oferecido na Biblioteca Circular (doação ou troca)
class Doacao {
  constructor(id, usuarioId, usuarioNome, dados) {
    this.id = id;
    this.usuarioId = usuarioId;
    this.usuarioNome = usuarioNome;
    this.titulo = dados.titulo;
    this.autor = dados.autor;
    this.genero = dados.genero || "Outros";
    this.tipo = dados.tipo === "troca" ? "troca" : "doacao";
    this.desejo = dados.desejo || "";       // na troca: o que a pessoa quer receber
    this.ponto = dados.ponto || PONTOS_COLETA[0].id;
    this.status = "oferecido";
    this.interessadoId = null;              // troca: quem propôs
    this.interessadoNome = "";
    this.destino = "";                       // repasse: para quem foi
    this.livroId = null;                     // quando entra no acervo
    this.exemplarCodigo = "";
    this.data = new Date().toISOString();
    this.historico = [{ status: "oferecido", data: this.data, nota: "" }];
  }
}

const STATUS_DOACAO = {
  oferecido: "Oferecido",
  proposta: "Proposta de troca recebida",
  recebido: "Recebido no ponto de coleta",
  incorporado: "Incorporado ao acervo",
  repassado: "Repassado a um leitor",
  trocado: "Troca concluída",
  recusado: "Não aceito",
  cancelado: "Cancelado"
};

class Biblioteca {
  constructor() {
    this.limparDados();
    if (!this.carregar()) {
      this.carregarAcervoInicial();
    }
    this.carregarSessao();
  }

  limparDados() {
    this.livros = [];
    this.usuarios = [];
    this.emprestimos = [];
    this.reservas = [];
    this.doacoes = [];
    this.avaliacoes = [];   // { usuarioId, usuarioNome, livroId, nota, texto, data }
    this.clubes = {};       // clubeId -> [usuarioId]
    this.mensagens = [];    // { id, clubeId, usuarioId, usuarioNome, texto, data }
    this.interesses = {};   // eventoId -> [usuarioId]
    this.inventario = null; // { inicio, conferidos: [codigo] }
    this.contadorMatricula = 0;
    this.contadores = {};
    this.acervoVersao = ACERVO_VERSAO;
    this.sessao = null;
  }

  // ---------- Perfis e sessão ----------

  get perfil() {
    return this.sessao ? this.sessao.perfil : "visitante";
  }

  get usuarioLogado() {
    if (!this.sessao || this.sessao.perfil !== "usuario") return null;
    return this.usuarios.find(u => u.id === this.sessao.usuarioId) || null;
  }

  entrarComoUsuario(matricula) {
    const numero = String(matricula || "").trim();
    if (!numero) throw new Error("Digite sua matrícula.");
    const usuario = this.usuarios.find(u => u.matricula === numero);
    if (!usuario) throw new Error("Matrícula não encontrada. Confira o número ou faça seu cadastro.");
    this.sessao = { perfil: "usuario", usuarioId: usuario.id };
    this.salvarSessao();
    return usuario;
  }

  entrarComoBibliotecario(pin) {
    if (String(pin || "").trim() !== PIN_BIBLIOTECARIO) throw new Error("PIN incorreto.");
    this.sessao = { perfil: "bibliotecario", usuarioId: null };
    this.salvarSessao();
  }

  sair() {
    this.sessao = null;
    this.salvarSessao();
  }

  exigirBibliotecario(acao) {
    if (this.perfil !== "bibliotecario") throw new Error(`Apenas o bibliotecário pode ${acao}.`);
  }

  exigirUsuario(acao) {
    if (this.perfil !== "usuario" || !this.usuarioLogado) throw new Error(`Entre com sua matrícula para ${acao}.`);
    return this.usuarioLogado;
  }

  salvarSessao() {
    try {
      if (this.sessao) localStorage.setItem("biblioteca-sessao", JSON.stringify(this.sessao));
      else localStorage.removeItem("biblioteca-sessao");
    } catch (e) { /* armazenamento indisponível */ }
  }

  carregarSessao() {
    try {
      const s = JSON.parse(localStorage.getItem("biblioteca-sessao"));
      if (s && s.perfil === "bibliotecario") this.sessao = { perfil: "bibliotecario", usuarioId: null };
      else if (s && s.perfil === "usuario" && this.usuarios.some(u => u.id === s.usuarioId)) this.sessao = s;
    } catch (e) {
      this.sessao = null;
    }
  }

  // ---------- Acervo e usuários ----------

  proximoId(lista, tipo) {
    const maior = lista.length ? Math.max(...lista.map(i => i.id)) : 0;
    this.contadores[tipo] = Math.max(this.contadores[tipo] || 0, maior) + 1;
    return this.contadores[tipo];
  }

  // Preenche os metadados de um livro a partir da linha do acervo inicial
  aplicarMetadados(livro, linha) {
    const [, , genero, original, paginas, serie, temas, sinopse, formatos] = linha;
    livro.genero = livro.genero || genero;
    livro.tituloOriginal = livro.tituloOriginal || original;
    livro.paginas = livro.paginas || paginas;
    livro.serie = livro.serie || serie;
    if (!livro.temas || !livro.temas.length) livro.temas = [...temas];
    livro.sinopse = livro.sinopse || sinopse;
    if (!livro.formatos || livro.formatos.length <= 1) livro.formatos = ["impresso", ...formatos];
  }

  criarLivroDoAcervo(linha) {
    const [titulo, autor, genero, original, , , , , , qtd] = linha;
    const livro = new Livro(this.proximoId(this.livros, "livro"), titulo, autor, genero, original);
    this.aplicarMetadados(livro, linha);
    for (let i = 0; i < (qtd || 1); i++) livro.adicionarExemplar();
    this.livros.push(livro);
    return livro;
  }

  carregarAcervoInicial() {
    ACERVO_INICIAL.forEach(linha => this.criarLivroDoAcervo(linha));
    this.salvar();
  }

  gerarMatricula() {
    this.contadorMatricula += 1;
    return `${new Date().getFullYear()}${String(this.contadorMatricula).padStart(4, "0")}`;
  }

  cadastrarUsuario(nome) {
    nome = String(nome || "").trim();
    if (nome.length < 3) throw new Error("Digite seu nome (mínimo de 3 letras).");
    const usuario = new Usuario(this.proximoId(this.usuarios, "usuario"), nome, this.gerarMatricula());
    this.usuarios.push(usuario);
    this.salvar();
    return usuario;
  }

  cadastrarLivro(titulo, autor, genero = "Outros", extras = {}) {
    this.exigirBibliotecario("cadastrar livros");
    titulo = String(titulo || "").trim();
    autor = String(autor || "").trim();
    if (!titulo || !autor) throw new Error("Informe o título e o autor do livro.");
    if (this.livroPorTituloAutor(titulo, autor)) throw new Error("Este livro já está no acervo.");
    const livro = new Livro(this.proximoId(this.livros, "livro"), titulo, autor, genero);
    livro.paginas = Number(extras.paginas) || 0;
    livro.temas = (extras.temas || []).filter(Boolean);
    livro.sinopse = extras.sinopse || "";
    livro.serie = extras.serie || "";
    const qtd = Math.max(1, Math.min(20, Number(extras.exemplares) || 1));
    for (let i = 0; i < qtd; i++) livro.adicionarExemplar(extras.origem || "acervo", extras.doacaoId || null);
    this.livros.push(livro);
    this.salvar();
    return livro;
  }

  livroPorTituloAutor(titulo, autor) {
    const chave = normalizar(`${titulo} ${autor}`);
    return this.livros.find(l => normalizar(`${l.titulo} ${l.autor}`) === chave) || null;
  }

  removerLivro(id) {
    this.exigirBibliotecario("remover livros");
    const livro = this.livros.find(l => l.id === id);
    if (livro && livro.emprestado) throw new Error("Não é possível remover um livro que está emprestado.");
    this.livros = this.livros.filter(l => l.id !== id);
    this.reservas.forEach(r => {
      if (r.livroId === id && r.status === "ativa") { r.status = "cancelada"; r.dataFim = new Date().toISOString(); }
    });
    this.salvar();
  }

  removerUsuario(id) {
    this.exigirBibliotecario("remover usuários");
    if (this.emprestimos.some(e => e.usuarioId === id && e.ativo)) throw new Error("Usuário possui empréstimo ativo.");
    this.usuarios = this.usuarios.filter(u => u.id !== id);
    this.reservas.forEach(r => { if (r.usuarioId === id && r.status === "ativa") r.status = "cancelada"; });
    this.salvar();
  }

  // ---------- Exemplares e QR Code ----------

  exemplarPorCodigo(codigo) {
    const cod = String(codigo || "").trim().toUpperCase();
    for (const livro of this.livros) {
      const ex = livro.exemplares.find(x => x.codigo === cod);
      if (ex) return { livro, exemplar: ex };
    }
    return null;
  }

  adicionarExemplar(livroId) {
    this.exigirBibliotecario("adicionar exemplares");
    const livro = this.livros.find(l => l.id === livroId);
    if (!livro) throw new Error("Livro não encontrado.");
    const ex = livro.adicionarExemplar();
    this.salvar();
    return ex;
  }

  alterarEstadoExemplar(codigo, estado) {
    this.exigirBibliotecario("alterar exemplares");
    const achado = this.exemplarPorCodigo(codigo);
    if (!achado) throw new Error("Exemplar não encontrado.");
    if (!["disponivel", "danificado", "perdido"].includes(estado)) throw new Error("Estado inválido.");
    if (achado.exemplar.estado === "emprestado") throw new Error("Registre a devolução antes de mudar o estado deste exemplar.");
    achado.exemplar.estado = estado;
    this.salvar();
    return achado;
  }

  historicoExemplar(codigo) {
    this.exigirBibliotecario("consultar o histórico do exemplar");
    const cod = String(codigo || "").trim().toUpperCase();
    return [...this.emprestimos].reverse().filter(e => e.exemplarCodigo === cod);
  }

  // Inventário físico: o bibliotecário confere (escaneia) cada exemplar na estante
  iniciarInventario() {
    this.exigirBibliotecario("fazer inventário");
    this.inventario = { inicio: new Date().toISOString(), conferidos: [] };
    this.salvar();
  }

  conferirNoInventario(codigo) {
    this.exigirBibliotecario("fazer inventário");
    if (!this.inventario) throw new Error("Inicie o inventário primeiro.");
    const achado = this.exemplarPorCodigo(codigo);
    if (!achado) throw new Error("Código não pertence ao acervo.");
    if (achado.exemplar.estado === "emprestado") throw new Error(`${achado.exemplar.codigo} consta como emprestado: registre a devolução primeiro.`);
    if (!this.inventario.conferidos.includes(achado.exemplar.codigo)) this.inventario.conferidos.push(achado.exemplar.codigo);
    if (achado.exemplar.estado === "perdido") achado.exemplar.estado = "disponivel"; // reapareceu
    this.salvar();
    return achado;
  }

  // Exemplares que deveriam estar na estante e ainda não foram conferidos
  pendentesInventario() {
    if (!this.inventario) return [];
    const pend = [];
    this.livros.forEach(l => l.exemplares.forEach(x => {
      if (["disponivel", "danificado"].includes(x.estado) && !this.inventario.conferidos.includes(x.codigo)) {
        pend.push({ livro: l, exemplar: x });
      }
    }));
    return pend;
  }

  finalizarInventario(marcarPerdidos = false) {
    this.exigirBibliotecario("fazer inventário");
    if (!this.inventario) throw new Error("Nenhum inventário em andamento.");
    const pendentes = this.pendentesInventario();
    if (marcarPerdidos) pendentes.forEach(p => { p.exemplar.estado = "perdido"; });
    const resultado = { conferidos: this.inventario.conferidos.length, faltando: pendentes.length };
    this.inventario = null;
    this.salvar();
    return resultado;
  }

  // ---------- Empréstimos e reservas ----------

  possuiAtraso(usuarioId) {
    return this.emprestimos.some(e => e.usuarioId === usuarioId && e.atrasado);
  }

  filaDe(livroId) {
    return this.reservas
      .filter(r => r.livroId === livroId && r.status === "ativa")
      .sort((a, b) => new Date(a.data) - new Date(b.data));
  }

  // Os exemplares livres vão primeiro para quem está na fila, na ordem de chegada
  podePegarAgora(livro, usuarioId) {
    if (!livro || !livro.disponivel) return false;
    const fila = this.filaDe(livro.id);
    const pos = fila.findIndex(r => r.usuarioId === usuarioId);
    const naFrente = pos >= 0 ? pos : fila.length;
    return livro.qtdDisponiveis > naFrente;
  }

  temEmprestimoAtivoDoTitulo(livroId, usuarioId) {
    return this.emprestimos.some(e => e.livroId === livroId && e.usuarioId === usuarioId && e.ativo);
  }

  validarEmprestimo(livro, usuario) {
    if (!livro || !usuario) throw new Error("Selecione um livro e um usuário.");
    if (this.possuiAtraso(usuario.id)) {
      throw new Error("Empréstimo bloqueado: há livro atrasado. Devolva para liberar novos empréstimos.");
    }
    if (this.temEmprestimoAtivoDoTitulo(livro.id, usuario.id)) throw new Error("Você já está com um exemplar deste livro.");
    if (!livro.disponivel) throw new Error("Não há exemplar disponível. Você pode entrar na fila de reserva.");
    if (!this.podePegarAgora(livro, usuario.id)) throw new Error("Os exemplares livres estão reservados para quem está na fila.");
    const ativos = this.emprestimos.filter(e => e.usuarioId === usuario.id && e.ativo).length;
    if (ativos >= MAX_EMPRESTIMOS) throw new Error(`Limite de ${MAX_EMPRESTIMOS} empréstimos ativos por usuário.`);
  }

  registrarEmprestimo(livro, exemplar, usuario) {
    const emp = new Emprestimo(
      this.proximoId(this.emprestimos, "emprestimo"), livro.id, usuario.id, PRAZO_DIAS,
      livro.titulo, usuario.nome, usuario.matricula, exemplar.codigo
    );
    exemplar.estado = "emprestado";
    this.emprestimos.push(emp);
    const reserva = this.filaDe(livro.id).find(r => r.usuarioId === usuario.id);
    if (reserva) { reserva.status = "atendida"; reserva.dataFim = new Date().toISOString(); }
    this.salvar();
    return emp;
  }

  // O usuário pega livros apenas em seu próprio nome
  emprestar(livroId, usuarioId) {
    if (this.perfil !== "usuario") throw new Error("Entre com sua matrícula para pegar livros emprestados.");
    if (usuarioId !== this.sessao.usuarioId) throw new Error("Você só pode pegar livros em seu próprio nome.");
    const livro = this.livros.find(l => l.id === livroId);
    const usuario = this.usuarios.find(u => u.id === usuarioId);
    this.validarEmprestimo(livro, usuario);
    const exemplar = livro.exemplares.find(x => x.estado === "disponivel");
    return this.registrarEmprestimo(livro, exemplar, usuario);
  }

  // Empréstimo no balcão: o bibliotecário escaneia o QR do exemplar e informa a matrícula
  emprestarNoBalcao(codigo, matricula) {
    this.exigirBibliotecario("registrar empréstimos no balcão");
    const achado = this.exemplarPorCodigo(codigo);
    if (!achado) throw new Error("Exemplar não encontrado.");
    const usuario = this.usuarios.find(u => u.matricula === String(matricula || "").trim());
    if (!usuario) throw new Error("Matrícula não encontrada.");
    if (achado.exemplar.estado !== "disponivel") throw new Error(`Este exemplar está ${ESTADOS_EXEMPLAR[achado.exemplar.estado].toLowerCase()}.`);
    this.validarEmprestimo(achado.livro, usuario);
    return this.registrarEmprestimo(achado.livro, achado.exemplar, usuario);
  }

  renovar(emprestimoId) {
    if (this.perfil !== "usuario") throw new Error("Entre com sua matrícula para renovar empréstimos.");
    const emp = this.emprestimos.find(e => e.id === emprestimoId);
    if (!emp || !emp.ativo) throw new Error("Empréstimo inválido.");
    if (emp.usuarioId !== this.sessao.usuarioId) throw new Error("Você só pode renovar os seus próprios empréstimos.");
    if (emp.atrasado) throw new Error("Empréstimo atrasado não pode ser renovado. Devolva o livro ao bibliotecário.");
    if (emp.renovacoes >= MAX_RENOVACOES) throw new Error(`Limite de ${MAX_RENOVACOES} renovações atingido.`);
    if (this.filaDe(emp.livroId).length) throw new Error("Há leitores na fila de reserva deste livro: não é possível renovar.");
    const novoPrazo = new Date(emp.dataPrevista);
    novoPrazo.setDate(novoPrazo.getDate() + PRAZO_DIAS);
    emp.dataPrevista = novoPrazo.toISOString();
    emp.renovacoes += 1;
    this.salvar();
    return emp;
  }

  devolver(emprestimoId) {
    this.exigirBibliotecario("registrar devoluções");
    const emp = this.emprestimos.find(e => e.id === emprestimoId);
    if (!emp || !emp.ativo) throw new Error("Empréstimo inválido.");
    emp.dataDevolucao = new Date().toISOString();
    const livro = this.livros.find(l => l.id === emp.livroId);
    if (livro) {
      const ex = livro.exemplares.find(x => x.codigo === emp.exemplarCodigo) || livro.exemplares.find(x => x.estado === "emprestado");
      if (ex) ex.estado = "disponivel";
    }
    this.salvar();
    return emp;
  }

  devolverPorCodigo(codigo) {
    this.exigirBibliotecario("registrar devoluções");
    const achado = this.exemplarPorCodigo(codigo);
    if (!achado) throw new Error("Exemplar não encontrado.");
    const emp = this.emprestimos.find(e => e.exemplarCodigo === achado.exemplar.codigo && e.ativo);
    if (!emp) throw new Error("Este exemplar não está emprestado.");
    return this.devolver(emp.id);
  }

  simularAtraso(emprestimoId) {
    this.exigirBibliotecario("simular atraso");
    const emp = this.emprestimos.find(e => e.id === emprestimoId);
    if (!emp || !emp.ativo) throw new Error("Só é possível simular atraso em empréstimo ativo.");
    const ontem = new Date();
    ontem.setDate(ontem.getDate() - 1);
    emp.dataPrevista = ontem.toISOString();
    this.salvar();
  }

  reservar(livroId) {
    const usuario = this.exigirUsuario("reservar livros");
    const livro = this.livros.find(l => l.id === livroId);
    if (!livro) throw new Error("Livro não encontrado.");
    if (this.temEmprestimoAtivoDoTitulo(livroId, usuario.id)) throw new Error("Você já está com este livro.");
    if (this.filaDe(livroId).some(r => r.usuarioId === usuario.id)) throw new Error("Você já está na fila deste livro.");
    if (this.podePegarAgora(livro, usuario.id)) throw new Error("Há exemplar disponível: você pode emprestar agora.");
    const ativas = this.reservas.filter(r => r.usuarioId === usuario.id && r.status === "ativa").length;
    if (ativas >= MAX_RESERVAS) throw new Error(`Limite de ${MAX_RESERVAS} reservas ativas.`);
    const r = new Reserva(this.proximoId(this.reservas, "reserva"), livroId, usuario.id, usuario.nome, livro.titulo);
    this.reservas.push(r);
    this.salvar();
    return { reserva: r, posicao: this.filaDe(livroId).length };
  }

  cancelarReserva(reservaId) {
    const usuario = this.exigirUsuario("cancelar reservas");
    const r = this.reservas.find(x => x.id === reservaId);
    if (!r || r.usuarioId !== usuario.id || r.status !== "ativa") throw new Error("Reserva inválida.");
    r.status = "cancelada";
    r.dataFim = new Date().toISOString();
    this.salvar();
  }

  reservasDoUsuario(usuarioId) {
    return this.reservas.filter(r => r.usuarioId === usuarioId && r.status === "ativa").map(r => {
      const livro = this.livros.find(l => l.id === r.livroId);
      return {
        reserva: r,
        livro,
        posicao: this.filaDe(r.livroId).findIndex(x => x.id === r.id) + 1,
        pronta: this.podePegarAgora(livro, usuarioId)
      };
    });
  }

  // ---------- Busca simples (por título/autor) ----------

  buscarLivros({ texto = "", genero = "", situacao = "", ordem = "", formato = "" } = {}) {
    const termo = normalizar(texto);
    const achados = this.livros.filter(l => {
      if (termo && !normalizar(`${l.titulo} ${l.autor}`).includes(termo)) return false;
      if (genero && l.genero !== genero) return false;
      if (situacao === "disponivel" && !l.disponivel) return false;
      if (situacao === "emprestado" && l.disponivel) return false;
      if (formato === "acessivel" && !l.formatos.some(f => FORMATOS_ACESSIVEIS.includes(f))) return false;
      if (formato && formato !== "acessivel" && !l.formatos.includes(formato)) return false;
      return true;
    });
    return this.ordenarLivros(achados, ordem);
  }

  ordenarLivros(lista, ordem) {
    const comparar = (a, b) => String(a).localeCompare(String(b), "pt-BR", { sensitivity: "base" });
    if (ordem === "titulo") lista.sort((a, b) => comparar(a.titulo, b.titulo));
    else if (ordem === "autor") lista.sort((a, b) => comparar(a.autor, b.autor) || comparar(a.titulo, b.titulo));
    else if (ordem === "genero") lista.sort((a, b) => comparar(a.genero, b.genero) || comparar(a.titulo, b.titulo));
    else if (ordem === "disponiveis") lista.sort((a, b) => Number(b.disponivel) - Number(a.disponivel) || comparar(a.titulo, b.titulo));
    else if (ordem === "nota") lista.sort((a, b) => (this.mediaAvaliacao(b.id).media || 0) - (this.mediaAvaliacao(a.id).media || 0));
    else if (ordem === "curtos") lista.sort((a, b) => (a.paginas || 9999) - (b.paginas || 9999));
    return lista;
  }

  emprestimoAtivoDe(livroId) {
    return this.emprestimos.find(e => e.livroId === livroId && e.ativo) || null;
  }

  emprestimosAtivosDe(livroId) {
    return this.emprestimos.filter(e => e.livroId === livroId && e.ativo);
  }

  // ---------- Histórico ----------

  tituloDe(emp) {
    const livro = this.livros.find(l => l.id === emp.livroId);
    return emp.livroTitulo || (livro ? livro.titulo : "(removido)");
  }

  nomeDe(emp) {
    const usuario = this.usuarios.find(u => u.id === emp.usuarioId);
    return emp.usuarioNome || (usuario ? usuario.nome : "(removido)");
  }

  matriculaDe(emp) {
    const usuario = this.usuarios.find(u => u.id === emp.usuarioId);
    return emp.usuarioMatricula || (usuario ? usuario.matricula : "");
  }

  historico({ livroId = null, usuarioId = null, texto = "", situacao = "" } = {}) {
    if (this.perfil === "visitante") throw new Error("Entre no sistema para ver empréstimos.");
    if (this.perfil === "usuario") usuarioId = this.sessao.usuarioId;
    const termo = normalizar(texto);
    return [...this.emprestimos].reverse().filter(e => {
      if (livroId !== null && e.livroId !== livroId) return false;
      if (usuarioId !== null && e.usuarioId !== usuarioId) return false;
      if (situacao === "andamento" && !(e.ativo && !e.atrasado)) return false;
      if (situacao === "atrasado" && !e.atrasado) return false;
      if (situacao === "devolvido" && e.ativo) return false;
      if (termo && !normalizar(`${this.tituloDe(e)} ${this.nomeDe(e)} ${this.matriculaDe(e)} ${e.exemplarCodigo}`).includes(termo)) return false;
      return true;
    });
  }

  exportarHistoricoCsv(filtros = {}) {
    this.exigirBibliotecario("exportar o histórico");
    const campo = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const cabecalho = ["Livro", "Exemplar", "Usuário", "Matrícula", "Retirada", "Prazo", "Devolução", "Renovações", "Situação", "Multa (R$)"];
    const linhas = this.historico(filtros).map(e => [
      this.tituloDe(e), e.exemplarCodigo || "", this.nomeDe(e), this.matriculaDe(e),
      new Date(e.dataEmprestimo).toLocaleString("pt-BR"),
      new Date(e.dataPrevista).toLocaleDateString("pt-BR"),
      e.ativo ? "" : new Date(e.dataDevolucao).toLocaleString("pt-BR"),
      e.renovacoes || 0,
      e.ativo ? (e.atrasado ? "Atrasado" : "Em andamento") : (e.devolvidoComAtraso ? "Devolvido com atraso" : "Devolvido"),
      e.multa.toFixed(2).replace(".", ",")
    ]);
    return "﻿" + [cabecalho, ...linhas].map(l => l.map(campo).join(";")).join("\r\n");
  }

  // ---------- Perfil de leitura (recomendações) ----------

  // Livros que a pessoa leu: devolvidos na biblioteca + marcados como "já li"
  livrosLidosDe(usuarioId) {
    const u = this.usuarios.find(x => x.id === usuarioId);
    const ids = new Set(u ? u.lidos : []);
    this.emprestimos.forEach(e => { if (e.usuarioId === usuarioId && !e.ativo) ids.add(e.livroId); });
    return ids;
  }

  alternarLido(livroId) {
    const u = this.exigirUsuario("marcar livros como lidos");
    const i = u.lidos.indexOf(livroId);
    if (i >= 0) u.lidos.splice(i, 1);
    else u.lidos.push(livroId);
    this.salvar();
    return i < 0;
  }

  salvarPreferencias(prefs) {
    const u = this.exigirUsuario("salvar preferências");
    u.preferencias = {
      generos: (prefs.generos || []).filter(g => GENEROS.includes(g)),
      temas: (prefs.temas || []).filter(t => TEMAS[t]),
      minutosPorDia: Math.max(5, Math.min(600, Number(prefs.minutosPorDia) || 30)),
      tamanho: ["curto", "medio", "longo"].includes(prefs.tamanho) ? prefs.tamanho : "",
      series: ["sim", "nao"].includes(prefs.series) ? prefs.series : ""
    };
    this.salvar();
    return u.preferencias;
  }

  salvarAcessibilidadeDoUsuario(config) {
    const u = this.usuarioLogado;
    if (!u) return;
    u.acessibilidade = config;
    this.salvar();
  }

  // ---------- Comunidade ----------

  avaliar(livroId, nota, texto = "") {
    const u = this.exigirUsuario("avaliar livros");
    const livro = this.livros.find(l => l.id === livroId);
    if (!livro) throw new Error("Livro não encontrado.");
    nota = Math.round(Number(nota));
    if (!(nota >= 1 && nota <= 5)) throw new Error("Escolha de 1 a 5 estrelas.");
    const leu = this.livrosLidosDe(u.id).has(livroId) || this.temEmprestimoAtivoDoTitulo(livroId, u.id);
    if (!leu) throw new Error("Avalie livros que você pegou na biblioteca ou marcou como lidos.");
    texto = String(texto || "").trim().slice(0, 600);
    let av = this.avaliacoes.find(a => a.usuarioId === u.id && a.livroId === livroId);
    if (!av) {
      av = { usuarioId: u.id, usuarioNome: u.nome, livroId, livroTitulo: livro.titulo };
      this.avaliacoes.push(av);
    }
    Object.assign(av, { nota, texto, data: new Date().toISOString() });
    this.salvar();
    return av;
  }

  avaliacoesDe(livroId) {
    return this.avaliacoes.filter(a => a.livroId === livroId).sort((a, b) => new Date(b.data) - new Date(a.data));
  }

  mediaAvaliacao(livroId) {
    const avs = this.avaliacoes.filter(a => a.livroId === livroId);
    if (!avs.length) return { media: 0, total: 0 };
    return { media: avs.reduce((s, a) => s + a.nota, 0) / avs.length, total: avs.length };
  }

  notaDoUsuario(livroId, usuarioId) {
    const av = this.avaliacoes.find(a => a.livroId === livroId && a.usuarioId === usuarioId);
    return av ? av.nota : 0;
  }

  definirMeta(livrosPorMes) {
    const u = this.exigirUsuario("definir uma meta");
    const n = Math.round(Number(livrosPorMes));
    if (!(n >= 1 && n <= 30)) throw new Error("A meta deve ficar entre 1 e 30 livros por mês.");
    u.metaMensal = n;
    this.salvar();
  }

  // Livros concluídos no mês atual (devoluções + marcados como lidos não contam data, então só devoluções)
  lidosNoMes(usuarioId = null, ref = new Date()) {
    const ini = new Date(ref.getFullYear(), ref.getMonth(), 1);
    return this.emprestimos.filter(e => !e.ativo && new Date(e.dataDevolucao) >= ini &&
      (usuarioId === null || e.usuarioId === usuarioId)).length;
  }

  entrarClube(clubeId) {
    const u = this.exigirUsuario("participar de clubes");
    if (!CLUBES.some(c => c.id === clubeId)) throw new Error("Clube inexistente.");
    const membros = this.clubes[clubeId] || (this.clubes[clubeId] = []);
    if (!membros.includes(u.id)) membros.push(u.id);
    this.salvar();
  }

  sairClube(clubeId) {
    const u = this.exigirUsuario("participar de clubes");
    this.clubes[clubeId] = (this.clubes[clubeId] || []).filter(id => id !== u.id);
    this.salvar();
  }

  membroDoClube(clubeId, usuarioId) {
    return (this.clubes[clubeId] || []).includes(usuarioId);
  }

  postarNoClube(clubeId, texto) {
    const u = this.exigirUsuario("participar das discussões");
    if (!this.membroDoClube(clubeId, u.id)) throw new Error("Entre no clube para participar da discussão.");
    texto = String(texto || "").trim();
    if (texto.length < 2) throw new Error("Escreva uma mensagem.");
    const msg = { id: this.proximoId(this.mensagens, "mensagem"), clubeId, usuarioId: u.id, usuarioNome: u.nome, texto: texto.slice(0, 500), data: new Date().toISOString() };
    this.mensagens.push(msg);
    this.salvar();
    return msg;
  }

  alternarInteresseEvento(eventoId) {
    const u = this.exigirUsuario("marcar interesse em eventos");
    const lista = this.interesses[eventoId] || (this.interesses[eventoId] = []);
    const i = lista.indexOf(u.id);
    if (i >= 0) lista.splice(i, 1); else lista.push(u.id);
    this.salvar();
    return i < 0;
  }

  // ---------- Biblioteca Circular ----------

  oferecerLivro(dados) {
    const u = this.exigirUsuario("oferecer livros");
    if (!String(dados.titulo || "").trim() || !String(dados.autor || "").trim()) throw new Error("Informe título e autor do livro.");
    if (dados.tipo === "troca" && !String(dados.desejo || "").trim()) throw new Error("Conte que tipo de livro você gostaria em troca.");
    const d = new Doacao(this.proximoId(this.doacoes, "doacao"), u.id, u.nome, {
      ...dados, titulo: String(dados.titulo).trim(), autor: String(dados.autor).trim(), desejo: String(dados.desejo || "").trim()
    });
    this.doacoes.push(d);
    this.salvar();
    return d;
  }

  mudarStatusDoacao(doacao, status, nota = "") {
    doacao.status = status;
    doacao.historico.push({ status, data: new Date().toISOString(), nota });
  }

  doacaoPorId(id) {
    const d = this.doacoes.find(x => x.id === id);
    if (!d) throw new Error("Oferta não encontrada.");
    return d;
  }

  proporTroca(doacaoId) {
    const u = this.exigirUsuario("propor trocas");
    const d = this.doacaoPorId(doacaoId);
    if (d.tipo !== "troca" || d.status !== "oferecido") throw new Error("Esta troca não está disponível.");
    if (d.usuarioId === u.id) throw new Error("Esta oferta é sua.");
    d.interessadoId = u.id;
    d.interessadoNome = u.nome;
    this.mudarStatusDoacao(d, "proposta", `${u.nome} quer trocar`);
    this.salvar();
  }

  responderTroca(doacaoId, aceitar) {
    const u = this.exigirUsuario("responder trocas");
    const d = this.doacaoPorId(doacaoId);
    if (d.usuarioId !== u.id || d.status !== "proposta") throw new Error("Nenhuma proposta para responder.");
    if (aceitar) {
      this.mudarStatusDoacao(d, "trocado", `Trocado com ${d.interessadoNome}`);
    } else {
      this.mudarStatusDoacao(d, "oferecido", "Proposta recusada");
      d.interessadoId = null;
      d.interessadoNome = "";
    }
    this.salvar();
  }

  cancelarOferta(doacaoId) {
    const u = this.exigirUsuario("cancelar ofertas");
    const d = this.doacaoPorId(doacaoId);
    if (d.usuarioId !== u.id || !["oferecido", "proposta"].includes(d.status)) throw new Error("Esta oferta não pode mais ser cancelada.");
    this.mudarStatusDoacao(d, "cancelado");
    this.salvar();
  }

  receberDoacao(doacaoId) {
    this.exigirBibliotecario("receber doações");
    const d = this.doacaoPorId(doacaoId);
    if (d.tipo !== "doacao" || d.status !== "oferecido") throw new Error("Esta doação não está aguardando entrega.");
    const ponto = PONTOS_COLETA.find(p => p.id === d.ponto);
    this.mudarStatusDoacao(d, "recebido", ponto ? ponto.nome : "");
    this.salvar();
  }

  // A doação vira um exemplar do acervo (de um título existente ou novo)
  incorporarDoacao(doacaoId) {
    this.exigirBibliotecario("incorporar doações");
    const d = this.doacaoPorId(doacaoId);
    if (d.status !== "recebido") throw new Error("Registre o recebimento antes de incorporar ao acervo.");
    let livro = this.livroPorTituloAutor(d.titulo, d.autor);
    let ex;
    if (livro) {
      ex = livro.adicionarExemplar("doacao", d.id);
    } else {
      livro = new Livro(this.proximoId(this.livros, "livro"), d.titulo, d.autor, d.genero);
      livro.origem = "doacao";
      this.livros.push(livro);
      ex = livro.adicionarExemplar("doacao", d.id);
    }
    d.livroId = livro.id;
    d.exemplarCodigo = ex.codigo;
    this.mudarStatusDoacao(d, "incorporado", `Exemplar ${ex.codigo}`);
    this.salvar();
    return { livro, exemplar: ex };
  }

  repassarDoacao(doacaoId, destino) {
    this.exigirBibliotecario("repassar doações");
    const d = this.doacaoPorId(doacaoId);
    if (d.status !== "recebido") throw new Error("Registre o recebimento antes de repassar.");
    destino = String(destino || "").trim();
    if (destino.length < 3) throw new Error("Informe para quem o livro foi repassado.");
    d.destino = destino;
    this.mudarStatusDoacao(d, "repassado", destino);
    this.salvar();
  }

  recusarDoacao(doacaoId, motivo = "") {
    this.exigirBibliotecario("recusar doações");
    const d = this.doacaoPorId(doacaoId);
    if (!["oferecido", "recebido"].includes(d.status) || d.tipo !== "doacao") throw new Error("Esta doação não pode ser recusada.");
    this.mudarStatusDoacao(d, "recusado", motivo);
    this.salvar();
  }

  // Quantas vezes o exemplar vindo da doação já foi emprestado (o "destino" da doação)
  emprestimosDaDoacao(doacao) {
    if (!doacao.exemplarCodigo) return 0;
    return this.emprestimos.filter(e => e.exemplarCodigo === doacao.exemplarCodigo).length;
  }

  // Período da campanha ativa: do início do mês atual ao fim do mês seguinte
  get campanha() {
    const hoje = new Date();
    const inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
    const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 2, 0, 23, 59, 59);
    const arrecadados = this.doacoes.filter(d => d.tipo === "doacao" && !["cancelado", "recusado"].includes(d.status) &&
      new Date(d.data) >= inicio && new Date(d.data) <= fim).length;
    return { nome: "Doe uma História", meta: 40, inicio, fim, arrecadados };
  }

  indicadoresCirculares() {
    const reutilizados = this.doacoes.filter(d => ["incorporado", "repassado", "trocado"].includes(d.status)).length;
    const pessoas = new Set();
    const codigosDoados = new Set();
    this.livros.forEach(l => l.exemplares.forEach(x => { if (x.origem === "doacao") codigosDoados.add(x.codigo); }));
    this.emprestimos.forEach(e => { if (codigosDoados.has(e.exemplarCodigo)) pessoas.add("u" + e.usuarioId); });
    this.doacoes.forEach(d => {
      if (d.status === "repassado") pessoas.add("r" + d.id);
      if (d.status === "trocado") { pessoas.add("u" + d.interessadoId); pessoas.add("u" + d.usuarioId); }
    });
    let total = 0;
    let comunitarios = 0;
    this.livros.forEach(l => l.exemplaresAtivos.forEach(x => { total++; if (x.origem === "doacao") comunitarios++; }));
    return {
      reutilizados,
      pessoas: pessoas.size,
      percentualComunitario: total ? (comunitarios / total) * 100 : 0,
      exemplaresComunitarios: comunitarios,
      totalExemplares: total
    };
  }

  // ---------- Armazenamento ----------

  salvar() {
    try {
      localStorage.setItem("biblioteca", JSON.stringify({
        livros: this.livros,
        usuarios: this.usuarios,
        emprestimos: this.emprestimos,
        reservas: this.reservas,
        doacoes: this.doacoes,
        avaliacoes: this.avaliacoes,
        clubes: this.clubes,
        mensagens: this.mensagens,
        interesses: this.interesses,
        inventario: this.inventario,
        contadorMatricula: this.contadorMatricula,
        contadores: this.contadores,
        acervoVersao: this.acervoVersao
      }));
    } catch (e) { /* armazenamento indisponível */ }
  }

  carregar() {
    try {
      const dados = JSON.parse(localStorage.getItem("biblioteca"));
      if (!dados) return false;
      this.livros = dados.livros.map(o => {
        const antigoDisponivel = o.disponivel; // versões antigas guardavam um booleano
        const copia = { ...o };
        delete copia.disponivel;
        const livro = Object.assign(Object.create(Livro.prototype), copia);
        if (!Array.isArray(livro.exemplares)) {
          livro.exemplares = [];
          const ex = livro.adicionarExemplar();
          if (antigoDisponivel === false) ex.estado = "emprestado";
        }
        return livro;
      });
      this.usuarios = dados.usuarios.map(o => Object.assign(new Usuario(), o));
      this.emprestimos = dados.emprestimos.map(o => Object.assign(new Emprestimo(0, 0, 0), o));
      this.reservas = (dados.reservas || []).map(o => Object.assign(new Reserva(), o));
      this.doacoes = (dados.doacoes || []).map(o => Object.assign(Object.create(Doacao.prototype), o));
      this.avaliacoes = dados.avaliacoes || [];
      this.clubes = dados.clubes || {};
      this.mensagens = dados.mensagens || [];
      this.interesses = dados.interesses || {};
      this.inventario = dados.inventario || null;
      this.contadorMatricula = dados.contadorMatricula || 0;
      this.contadores = dados.contadores || {};
      this.acervoVersao = dados.acervoVersao || 1;
      this.atualizarDadosAntigos();
      this.completarAcervo();
      return true;
    } catch (e) {
      this.limparDados();
      return false;
    }
  }

  // Quem já tinha dados salvos recebe os livros novos do acervo (uma única vez, por versão),
  // sem trazer de volta livros que o bibliotecário removeu antes.
  completarAcervo() {
    if (this.acervoVersao >= ACERVO_VERSAO) return;
    const inicioNovos = this.acervoVersao <= 1 ? 12 : (this.acervoVersao === 2 ? 40 : ACERVO_INICIAL.length);
    ACERVO_INICIAL.slice(inicioNovos).forEach(linha => {
      if (!this.livros.some(l => normalizar(l.titulo) === normalizar(linha[0]))) this.criarLivroDoAcervo(linha);
    });
    // Títulos do acervo que agora têm mais de um exemplar
    if (this.acervoVersao < 3) {
      this.livros.forEach(l => {
        const linha = ACERVO_INICIAL.find(a => a[0] === l.titulo);
        if (linha) while (l.exemplares.length < (linha[9] || 1)) l.adicionarExemplar();
      });
    }
    this.acervoVersao = ACERVO_VERSAO;
    this.salvar();
  }

  // Completa dados salvos por versões anteriores
  atualizarDadosAntigos() {
    this.livros.forEach(l => {
      const base = ACERVO_INICIAL.find(a => a[0] === l.titulo);
      if (!l.genero) l.genero = base ? base[2] : "Outros";
      if (l.tituloOriginal === undefined) l.tituloOriginal = base ? base[3] : "";
      if (l.capaUrl === undefined) l.capaUrl = null;
      if (!Array.isArray(l.temas)) l.temas = [];
      if (!Array.isArray(l.formatos)) l.formatos = ["impresso"];
      if (l.paginas === undefined) l.paginas = 0;
      if (l.serie === undefined) l.serie = "";
      if (l.sinopse === undefined) l.sinopse = "";
      if (base) this.aplicarMetadados(l, base);
    });
    this.usuarios.forEach(u => {
      if (!Array.isArray(u.lidos)) u.lidos = [];
      if (u.preferencias === undefined) u.preferencias = null;
      if (u.metaMensal === undefined) u.metaMensal = 0;
      if (u.acessibilidade === undefined) u.acessibilidade = null;
    });
    this.emprestimos.forEach(e => {
      const livro = this.livros.find(l => l.id === e.livroId);
      const usuario = this.usuarios.find(u => u.id === e.usuarioId);
      if (!e.livroTitulo && livro) e.livroTitulo = livro.titulo;
      if (!e.usuarioNome && usuario) e.usuarioNome = usuario.nome;
      if (!e.usuarioMatricula && usuario) e.usuarioMatricula = usuario.matricula || "";
      if (!e.exemplarCodigo && livro) {
        // empréstimo antigo: liga ao exemplar emprestado (ativo) ou ao primeiro exemplar
        const ex = e.ativo ? livro.exemplares.find(x => x.estado === "emprestado") : livro.exemplares[0];
        e.exemplarCodigo = ex ? ex.codigo : "";
      }
      if (e.exemplarCodigo === undefined) e.exemplarCodigo = "";
    });
  }
}
