// ===================== DADOS DE DEMONSTRAÇÃO =====================
// Gera um histórico realista (leitores, empréstimos dos últimos meses, reservas, avaliações,
// doações e clubes) para o painel de dados, as recomendações e a comunidade terem o que mostrar.
// Só o bibliotecário pode gerar, e os números são sempre os mesmos (semente fixa).

const NOMES_DEMO = [
  "Ana Beatriz Souza", "Lucas Ferreira", "Júlia Martins", "Gabriel Oliveira", "Mariana Costa", "Pedro Henrique Lima",
  "Beatriz Rocha", "Rafael Almeida", "Larissa Gomes", "Thiago Ribeiro", "Camila Duarte", "Felipe Nunes",
  "Isabela Carvalho", "Matheus Pires", "Letícia Barbosa", "Gustavo Teixeira", "Yasmin Moreira", "Vinícius Castro"
];

// Grupos de gosto: cada leitor demo prefere um grupo de gêneros
const GOSTOS_DEMO = [
  ["Fantasia"], ["Fantasia", "Distopia"], ["Romance", "Comédia romântica"], ["Drama", "Romance"],
  ["Suspense"], ["Distopia", "Ficção científica"], ["Filosofia e ideias", "Ficção científica"]
];

const RESENHAS_DEMO = {
  5: ["Não consegui parar de ler!", "Virou um dos meus favoritos.", "Chorei, ri e quero reler.", "Recomendo de olhos fechados."],
  4: ["Muito bom, o final surpreende.", "Gostei bastante, leitura rápida.", "Personagens marcantes."],
  3: ["Bom, mas o meio é um pouco lento.", "Esperava mais, mas valeu a leitura."],
  2: ["Não fez muito meu estilo."]
};

const MENSAGENS_DEMO = {
  fantasia: ["Alguém mais ficou obcecado pelos dragões de Quarta Asa?", "Próximo encontro: vamos discutir o final de Uma Corte de Névoa e Fúria!", "Estou na fila de Quarta Asa há uma semana 😅"],
  suspense: ["Verity me deixou sem dormir.", "Quem acertou o plot twist de A Paciente Silenciosa?"],
  romance: ["Proponho Orgulho e Preconceito como leitura de dezembro 💌", "Heartstopper é conforto em forma de livro."],
  distopia: ["Silo e Correr ou Morrer têm muito em comum: sociedades isoladas e segredos.", "1984 continua assustadoramente atual."],
  ideias: ["O Mundo de Sofia é uma ótima porta de entrada para filosofia."]
};

function gerarDadosDemonstracao(bib) {
  bib.exigirBibliotecario("gerar dados de demonstração");
  if (bib.usuarios.some(u => u.demo)) throw new Error("Os dados de demonstração já foram gerados.");
  const rnd = aleatorioComSemente(2026);
  const escolher = lista => lista[Math.floor(rnd() * lista.length)];
  const agora = Date.now();
  const diasAtras = d => new Date(agora - d * DIA_MS);
  const livroPorTitulo = t => bib.livros.find(l => l.titulo === t);

  // O acervo "existe" há alguns meses (para a análise de livros parados)
  bib.livros.forEach(l => {
    if (new Date(l.cadastradoEm) > diasAtras(100)) l.cadastradoEm = diasAtras(130).toISOString();
    l.exemplares.forEach(x => { if (new Date(x.adicionadoEm) > diasAtras(100)) x.adicionadoEm = diasAtras(130).toISOString(); });
  });

  // Leitores
  const leitores = NOMES_DEMO.map((nome, i) => {
    const u = new Usuario(bib.proximoId(bib.usuarios, "usuario"), nome, bib.gerarMatricula());
    u.demo = true;
    u.gosto = GOSTOS_DEMO[i % GOSTOS_DEMO.length];
    u.cadastradoEm = diasAtras(120 - i).toISOString();
    u.metaMensal = [2, 3, 4][i % 3];
    bib.usuarios.push(u);
    return u;
  });

  // Peso de procura de cada título ao longo do tempo:
  // fantasia cresce nos últimos 30 dias, drama perde força, alguns títulos ficam parados.
  const parados = new Set(["Querido John", "Todas as Suas Imperfeições", "Novembro, 9", "Dom Casmurro", "Sapiens", "O Duque e Eu"]);
  const quentes = { "Quarta Asa": 4, "A Biblioteca da Meia-Noite": 2.2, "Verity": 2, "Jogos Vorazes": 1.6, "Asas de Ferro": 2, "Silo": 1.4, "Correr ou Morrer": 1.5, "É Assim que Acaba": 1.5 };
  const peso = (livro, dias, leitor) => {
    if (parados.has(livro.titulo)) return dias > 75 ? 0.3 : 0;
    let p = quentes[livro.titulo] || 1;
    if (leitor.gosto.includes(livro.genero)) p *= 5;
    if (livro.genero === "Fantasia" && dias <= 30) p *= 2.2;
    if (livro.genero === "Drama" && dias <= 30) p *= 0.35;
    return p;
  };
  const sortearLivro = (leitor, dias) => {
    const pesos = bib.livros.map(l => peso(l, dias, leitor));
    let alvo = rnd() * pesos.reduce((a, b) => a + b, 0);
    for (let i = 0; i < pesos.length; i++) { alvo -= pesos[i]; if (alvo <= 0) return bib.livros[i]; }
    return bib.livros[0];
  };
  // Horário típico: mais à noite e à tarde; mais às quartas e quintas
  const sortearData = dias => {
    const d = diasAtras(dias);
    const r = rnd();
    const hora = r < 0.45 ? 18 + Math.floor(rnd() * 4) : r < 0.8 ? 13 + Math.floor(rnd() * 5) : 8 + Math.floor(rnd() * 4);
    d.setHours(hora, Math.floor(rnd() * 60), 0, 0);
    return d;
  };

  const livreAte = new Map(); // código do exemplar -> data em que fica livre
  const ativosPorLeitor = new Map();
  const reservasDemo = [];
  for (let dias = 95; dias >= 0; dias--) {
    const diaSemana = diasAtras(dias).getDay();
    const qtd = Math.round((diaSemana === 3 || diaSemana === 4 ? 3.4 : diaSemana === 0 ? 0.8 : 2.2) * (0.6 + rnd() * 0.8));
    for (let n = 0; n < qtd; n++) {
      const leitor = escolher(leitores);
      const livro = sortearLivro(leitor, dias);
      const inicio = sortearData(dias);
      if (inicio > new Date(agora)) continue;
      const ex = livro.exemplares.find(x => !livreAte.has(x.codigo) || livreAte.get(x.codigo) <= inicio);
      if (!ex) {
        // Sem exemplar: a pessoa entra na fila (demanda não atendida)
        reservasDemo.push({ livro, leitor, data: inicio });
        continue;
      }
      const duracao = 3 + Math.floor(rnd() * 8) + (rnd() < 0.12 ? 4 + Math.floor(rnd() * 5) : 0);
      let devolucao = new Date(inicio.getTime() + duracao * DIA_MS + rnd() * 6 * 3600000);
      const ativos = ativosPorLeitor.get(leitor.id) || 0;
      if (devolucao > new Date(agora) && ativos >= 2) devolucao = new Date(agora - 3600000);
      if (devolucao <= inicio) continue;
      const e = new Emprestimo(bib.proximoId(bib.emprestimos, "emprestimo"), livro.id, leitor.id, PRAZO_DIAS, livro.titulo, leitor.nome, leitor.matricula, ex.codigo);
      e.dataEmprestimo = inicio.toISOString();
      const prazo = new Date(inicio.getTime() + PRAZO_DIAS * DIA_MS);
      if (duracao > 8 && duracao <= 12 && rnd() < 0.5) { prazo.setDate(prazo.getDate() + PRAZO_DIAS); e.renovacoes = 1; }
      e.dataPrevista = prazo.toISOString();
      if (devolucao <= new Date(agora)) {
        e.dataDevolucao = devolucao.toISOString();
      } else {
        ex.estado = "emprestado";
        ativosPorLeitor.set(leitor.id, ativos + 1);
      }
      livreAte.set(ex.codigo, devolucao);
      bib.emprestimos.push(e);
    }
  }
  bib.emprestimos.sort((a, b) => new Date(a.dataEmprestimo) - new Date(b.dataEmprestimo));

  // Quarta Asa: procura muito acima da oferta (exemplo do indicador de demanda não atendida)
  const quarta = livroPorTitulo("Quarta Asa");
  if (quarta) {
    for (let i = 0; i < 30 - reservasDemo.filter(r => r.livro === quarta && r.data > diasAtras(30)).length; i++) {
      reservasDemo.push({ livro: quarta, leitor: escolher(leitores), data: sortearData(1 + Math.floor(rnd() * 29)) });
    }
  }
  reservasDemo.sort((a, b) => a.data - b.data).forEach(({ livro, leitor, data }) => {
    const r = new Reserva(bib.proximoId(bib.reservas, "reserva"), livro.id, leitor.id, leitor.nome, livro.titulo);
    r.data = data.toISOString();
    const recente = data > diasAtras(6);
    const jaNaFila = bib.reservas.some(x => x.livroId === livro.id && x.usuarioId === leitor.id && x.status === "ativa");
    const comLivro = bib.emprestimos.some(e => e.livroId === livro.id && e.usuarioId === leitor.id && e.ativo);
    if (recente && !jaNaFila && !comLivro && !livro.disponivel) {
      r.status = "ativa";
    } else {
      r.status = rnd() < 0.55 ? "atendida" : "expirada";
      r.dataFim = new Date(Math.min(agora, data.getTime() + (2 + rnd() * 6) * DIA_MS)).toISOString();
    }
    bib.reservas.push(r);
  });

  // Avaliações de quem devolveu
  const avaliados = new Set();
  bib.emprestimos.filter(e => !e.ativo).forEach(e => {
    const chave = e.usuarioId + "-" + e.livroId;
    if (avaliados.has(chave) || rnd() > 0.45) return;
    avaliados.add(chave);
    const livro = bib.livros.find(l => l.id === e.livroId);
    const leitor = leitores.find(u => u.id === e.usuarioId);
    let nota = 3 + Math.round(rnd() * 2);
    if (leitor.gosto.includes(livro.genero)) nota = Math.min(5, nota + 1);
    if (rnd() < 0.08) nota = 2;
    bib.avaliacoes.push({
      usuarioId: leitor.id, usuarioNome: leitor.nome, livroId: livro.id, livroTitulo: livro.titulo, nota,
      texto: rnd() < 0.6 ? escolher(RESENHAS_DEMO[nota] || RESENHAS_DEMO[4]) : "",
      data: new Date(new Date(e.dataDevolucao).getTime() + 3600000).toISOString()
    });
  });

  // Preferências de alguns leitores
  leitores.forEach((u, i) => {
    if (i % 2 === 0) u.preferencias = { generos: [...u.gosto], temas: [], minutosPorDia: 20 + (i % 4) * 15, tamanho: "", series: "" };
  });

  // Biblioteca Circular
  const doacoes = [
    { u: 0, titulo: "Leitura de Praia", autor: "Emily Henry", genero: "Comédia romântica", tipo: "doacao", fim: "incorporado", dias: 70 },
    { u: 3, titulo: "A Garota no Trem", autor: "Paula Hawkins", genero: "Suspense", tipo: "doacao", fim: "incorporado", dias: 64 },
    { u: 5, titulo: "Jogos Vorazes", autor: "Suzanne Collins", genero: "Distopia", tipo: "doacao", fim: "incorporado", dias: 55 },
    { u: 7, titulo: "O Hobbit", autor: "J. R. R. Tolkien", genero: "Fantasia", tipo: "doacao", fim: "incorporado", dias: 40 },
    { u: 9, titulo: "Harry Potter e a Pedra Filosofal", autor: "J. K. Rowling", genero: "Fantasia", tipo: "doacao", fim: "repassado", dias: 33, destino: "Escola Estadual Monteiro Lobato (campanha)" },
    { u: 2, titulo: "Extraordinário", autor: "R. J. Palacio", genero: "Drama", tipo: "doacao", fim: "recebido", dias: 9 },
    { u: 11, titulo: "Torto Arado", autor: "Itamar Vieira Junior", genero: "Drama", tipo: "doacao", fim: "oferecido", dias: 4 },
    { u: 13, titulo: "Os Miseráveis", autor: "Victor Hugo", genero: "Drama", tipo: "doacao", fim: "oferecido", dias: 2 },
    { u: 4, titulo: "Vermelho, Branco e Sangue Azul", autor: "Casey McQuiston", genero: "Comédia romântica", tipo: "troca", desejo: "Uma fantasia (qualquer da Sarah J. Maas)", fim: "trocado", dias: 25, com: 6 },
    { u: 8, titulo: "Duna", autor: "Frank Herbert", genero: "Ficção científica", tipo: "troca", desejo: "Algum suspense psicológico", fim: "proposta", dias: 7, com: 10 },
    { u: 12, titulo: "A Rainha do Nada", autor: "Holly Black", genero: "Fantasia", tipo: "troca", desejo: "Romance de época", fim: "oferecido", dias: 3 },
    { u: 14, titulo: "Coraline", autor: "Neil Gaiman", genero: "Fantasia", tipo: "troca", desejo: "Livros de terror ou suspense", fim: "oferecido", dias: 1 }
  ];
  doacoes.forEach(dd => {
    const dono = leitores[dd.u];
    const d = new Doacao(bib.proximoId(bib.doacoes, "doacao"), dono.id, dono.nome, { ...dd, ponto: escolher(PONTOS_COLETA).id });
    d.data = diasAtras(dd.dias).toISOString();
    d.historico = [{ status: "oferecido", data: d.data, nota: "" }];
    const passo = (status, dias, nota = "") => { d.status = status; d.historico.push({ status, data: diasAtras(dias).toISOString(), nota }); };
    if (["recebido", "incorporado", "repassado"].includes(dd.fim)) passo("recebido", dd.dias - 2, (PONTOS_COLETA.find(p => p.id === d.ponto) || {}).nome);
    if (dd.fim === "incorporado") {
      let livro = livroPorTitulo(dd.titulo);
      if (!livro) {
        livro = new Livro(bib.proximoId(bib.livros, "livro"), dd.titulo, dd.autor, dd.genero);
        livro.origem = "doacao";
        livro.cadastradoEm = diasAtras(dd.dias - 3).toISOString();
        bib.livros.push(livro);
      }
      const ex = livro.adicionarExemplar("doacao", d.id);
      ex.adicionadoEm = diasAtras(dd.dias - 3).toISOString();
      d.livroId = livro.id;
      d.exemplarCodigo = ex.codigo;
      passo("incorporado", dd.dias - 3, `Exemplar ${ex.codigo}`);
      // O exemplar doado já circulou (destino da doação)
      let t = dd.dias - 5;
      while (t > 8) {
        const leitor = escolher(leitores);
        const e = new Emprestimo(bib.proximoId(bib.emprestimos, "emprestimo"), livro.id, leitor.id, PRAZO_DIAS, livro.titulo, leitor.nome, leitor.matricula, ex.codigo);
        e.dataEmprestimo = sortearData(t).toISOString();
        e.dataPrevista = new Date(new Date(e.dataEmprestimo).getTime() + PRAZO_DIAS * DIA_MS).toISOString();
        e.dataDevolucao = new Date(new Date(e.dataEmprestimo).getTime() + (4 + rnd() * 3) * DIA_MS).toISOString();
        bib.emprestimos.push(e);
        t -= 9 + Math.floor(rnd() * 6);
      }
    }
    if (dd.fim === "repassado") { d.destino = dd.destino; passo("repassado", dd.dias - 6, dd.destino); }
    if (dd.fim === "proposta" || dd.fim === "trocado") {
      const outro = leitores[dd.com];
      d.interessadoId = outro.id;
      d.interessadoNome = outro.nome;
      passo("proposta", dd.dias - 2, `${outro.nome} quer trocar`);
      if (dd.fim === "trocado") passo("trocado", dd.dias - 4, `Trocado com ${outro.nome}`);
    }
    bib.doacoes.push(d);
  });
  bib.emprestimos.sort((a, b) => a.id - b.id);

  // Comunidade: clubes, mensagens e interesse em eventos
  CLUBES.forEach(c => {
    bib.clubes[c.id] = leitores.filter(u => u.gosto.includes(c.genero) || rnd() < 0.15).map(u => u.id);
    (MENSAGENS_DEMO[c.id] || []).forEach((texto, i) => {
      const autor = leitores.find(u => bib.clubes[c.id].includes(u.id)) || leitores[0];
      const membros = bib.clubes[c.id];
      const quem = leitores.find(u => u.id === membros[(i * 3) % membros.length]) || autor;
      bib.mensagens.push({ id: bib.proximoId(bib.mensagens, "mensagem"), clubeId: c.id, usuarioId: quem.id, usuarioNome: quem.nome, texto, data: diasAtras(6 - i * 2).toISOString() });
    });
  });
  eventosDaBiblioteca().forEach((ev, i) => { bib.interesses[ev.id] = leitores.filter(() => rnd() < 0.3 + i * 0.1).map(u => u.id); });

  bib.salvar();
  return { leitores: leitores.length, emprestimos: bib.emprestimos.length, reservas: bib.reservas.length };
}

// Eventos literários (datas relativas a hoje, para a demonstração estar sempre "no futuro")
function eventosDaBiblioteca() {
  const prox = (diaSemana, semanas = 0, hora = 18) => {
    const d = new Date();
    d.setDate(d.getDate() + ((diaSemana - d.getDay() + 7) % 7 || 7) + semanas * 7);
    d.setHours(hora, 0, 0, 0);
    return d;
  };
  return [
    { id: "ev-sarau", nome: "Sarau de poesia e leitura em voz alta", data: prox(5, 0, 19), local: "Auditório da Biblioteca" },
    { id: "ev-troca", nome: "Feira de trocas da Biblioteca Circular", data: prox(6, 0, 10), local: "Pátio do Bloco B" },
    { id: "ev-clube", nome: "Encontro do Clube Dragões & Fadas: Quarta Asa", data: prox(3, 1, 18), local: "Sala de estudos 2" },
    { id: "ev-autor", nome: "Bate-papo: como escrever seu primeiro livro", data: prox(4, 2, 19), local: "Online" }
  ];
}
