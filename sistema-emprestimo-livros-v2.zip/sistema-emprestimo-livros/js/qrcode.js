// ===================== GERADOR DE QR CODE =====================
// Implementação própria e compacta (QR Code modelo 2, modo byte, correção de erro nível M,
// versões 1 a 10), para o sistema funcionar sem internet e sem bibliotecas externas.

const QRCode = (() => {
  const ECC_POR_BLOCO = [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26]; // nível M, por versão
  const BLOCOS = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];

  function mul(x, y) {
    let z = 0;
    for (let i = 7; i >= 0; i--) {
      z = (z << 1) ^ ((z >>> 7) * 0x11D);
      z ^= ((y >>> i) & 1) * x;
    }
    return z & 0xFF;
  }

  function divisorRS(grau) {
    const r = new Array(grau).fill(0);
    r[grau - 1] = 1;
    let raiz = 1;
    for (let i = 0; i < grau; i++) {
      for (let j = 0; j < r.length; j++) {
        r[j] = mul(r[j], raiz);
        if (j + 1 < r.length) r[j] ^= r[j + 1];
      }
      raiz = mul(raiz, 0x02);
    }
    return r;
  }

  function restoRS(dados, divisor) {
    const r = divisor.map(() => 0);
    for (const b of dados) {
      const fator = b ^ r.shift();
      r.push(0);
      divisor.forEach((c, i) => { r[i] ^= mul(c, fator); });
    }
    return r;
  }

  function modulosDeDados(v) {
    let r = (16 * v + 128) * v + 64;
    if (v >= 2) {
      const n = Math.floor(v / 7) + 2;
      r -= (25 * n - 10) * n - 55;
      if (v >= 7) r -= 36;
    }
    return r;
  }

  const codewordsDeDados = v => Math.floor(modulosDeDados(v) / 8) - ECC_POR_BLOCO[v] * BLOCOS[v];

  function posicoesAlinhamento(v) {
    if (v === 1) return [];
    const n = Math.floor(v / 7) + 2;
    const tam = v * 4 + 17;
    const passo = Math.ceil((v * 4 + 4) / (n * 2 - 2)) * 2;
    const r = [6];
    for (let p = tam - 7; r.length < n; p -= passo) r.splice(1, 0, p);
    return r;
  }

  function gerar(texto) {
    const bytes = Array.from(new TextEncoder().encode(String(texto)));
    let v = 1;
    while (v <= 10 && 4 + (v < 10 ? 8 : 16) + bytes.length * 8 > codewordsDeDados(v) * 8) v++;
    if (v > 10) throw new Error("Texto longo demais para o QR Code.");
    const tam = v * 4 + 17;
    const capacidade = codewordsDeDados(v) * 8;

    // Bits: modo byte (0100), tamanho, dados, terminador e preenchimento
    const bits = [];
    const poe = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    poe(4, 4);
    poe(bytes.length, v < 10 ? 8 : 16);
    bytes.forEach(b => poe(b, 8));
    poe(0, Math.min(4, capacidade - bits.length));
    poe(0, (8 - bits.length % 8) % 8);
    for (let pad = 0xEC; bits.length < capacidade; pad ^= 0xEC ^ 0x11) poe(pad, 8);
    const dados = [];
    for (let i = 0; i < bits.length; i += 8) dados.push(parseInt(bits.slice(i, i + 8).join(""), 2));

    // Correção de erro e intercalação dos blocos
    const nBlocos = BLOCOS[v];
    const eccLen = ECC_POR_BLOCO[v];
    const brutos = Math.floor(modulosDeDados(v) / 8);
    const curtos = nBlocos - brutos % nBlocos;
    const lenCurto = Math.floor(brutos / nBlocos);
    const div = divisorRS(eccLen);
    const blocos = [];
    for (let i = 0, k = 0; i < nBlocos; i++) {
      const dat = dados.slice(k, k + lenCurto - eccLen + (i < curtos ? 0 : 1));
      k += dat.length;
      const ecc = restoRS(dat, div);
      if (i < curtos) dat.push(0);
      blocos.push(dat.concat(ecc));
    }
    const finais = [];
    for (let i = 0; i < blocos[0].length; i++) {
      blocos.forEach((b, j) => { if (i !== lenCurto - eccLen || j >= curtos) finais.push(b[i]); });
    }

    // Matriz
    const m = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const fx = Array.from({ length: tam }, () => new Array(tam).fill(false));
    const fixa = (x, y, escuro) => { m[y][x] = escuro; fx[y][x] = true; };

    for (let i = 0; i < tam; i++) { fixa(6, i, i % 2 === 0); fixa(i, 6, i % 2 === 0); }
    const localizador = (x, y) => {
      for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
        const d = Math.max(Math.abs(dx), Math.abs(dy));
        const xx = x + dx, yy = y + dy;
        if (xx >= 0 && xx < tam && yy >= 0 && yy < tam) fixa(xx, yy, d !== 2 && d !== 4);
      }
    };
    localizador(3, 3); localizador(tam - 4, 3); localizador(3, tam - 4);
    const al = posicoesAlinhamento(v);
    al.forEach((a, i) => al.forEach((b, j) => {
      if ((i === 0 && j === 0) || (i === 0 && j === al.length - 1) || (i === al.length - 1 && j === 0)) return;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) fixa(a + dx, b + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }));

    const formato = mascara => {
      const d = (0 << 3) | mascara; // nível M = 00
      let r = d;
      for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
      const b = ((d << 10) | r) ^ 0x5412;
      const bit = i => ((b >>> i) & 1) !== 0;
      for (let i = 0; i <= 5; i++) fixa(8, i, bit(i));
      fixa(8, 7, bit(6)); fixa(8, 8, bit(7)); fixa(7, 8, bit(8));
      for (let i = 9; i < 15; i++) fixa(14 - i, 8, bit(i));
      for (let i = 0; i < 8; i++) fixa(tam - 1 - i, 8, bit(i));
      for (let i = 8; i < 15; i++) fixa(8, tam - 15 + i, bit(i));
      fixa(8, tam - 8, true);
    };
    formato(0);
    if (v >= 7) {
      let r = v;
      for (let i = 0; i < 12; i++) r = (r << 1) ^ ((r >>> 11) * 0x1F25);
      const b = (v << 12) | r;
      for (let i = 0; i < 18; i++) {
        const bit = ((b >>> i) & 1) !== 0;
        const a = tam - 11 + i % 3, c = Math.floor(i / 3);
        fixa(a, c, bit); fixa(c, a, bit);
      }
    }

    // Dados em zigue-zague
    let i = 0;
    for (let dir = tam - 1; dir >= 1; dir -= 2) {
      if (dir === 6) dir = 5;
      for (let vert = 0; vert < tam; vert++) {
        for (let j = 0; j < 2; j++) {
          const x = dir - j;
          const subindo = ((dir + 1) & 2) === 0;
          const y = subindo ? tam - 1 - vert : vert;
          if (!fx[y][x] && i < finais.length * 8) {
            m[y][x] = ((finais[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0;
            i++;
          }
        }
      }
    }

    const MASCARAS = [
      (x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
      (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => (x * y) % 2 + (x * y) % 3 === 0,
      (x, y) => ((x * y) % 2 + (x * y) % 3) % 2 === 0, (x, y) => ((x + y) % 2 + (x * y) % 3) % 2 === 0
    ];
    const aplicar = k => {
      for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) if (!fx[y][x] && MASCARAS[k](x, y)) m[y][x] = !m[y][x];
    };
    const penalidade = () => {
      let p = 0;
      const linhas = (get) => {
        for (let a = 0; a < tam; a++) {
          let run = 1;
          for (let b = 1; b <= tam; b++) {
            if (b < tam && get(a, b) === get(a, b - 1)) run++;
            else { if (run >= 5) p += 3 + run - 5; run = 1; }
          }
          for (let b = 0; b + 10 < tam; b++) {
            const s = Array.from({ length: 11 }, (_, k) => get(a, b + k) ? 1 : 0).join("");
            if (s === "10111010000" || s === "00001011101") p += 40;
          }
        }
      };
      linhas((a, b) => m[a][b]);
      linhas((a, b) => m[b][a]);
      let escuros = 0;
      for (let y = 0; y < tam; y++) for (let x = 0; x < tam; x++) {
        if (m[y][x]) escuros++;
        if (x < tam - 1 && y < tam - 1 && m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
      }
      const total = tam * tam;
      p += Math.max(0, Math.ceil(Math.abs(escuros * 20 - total * 10) / total) - 1) * 10;
      return p;
    };
    let melhor = 0, menor = Infinity;
    for (let k = 0; k < 8; k++) {
      aplicar(k); formato(k);
      const p = penalidade();
      if (p < menor) { menor = p; melhor = k; }
      aplicar(k);
    }
    aplicar(melhor);
    formato(melhor);
    return m;
  }

  // SVG pronto para a página (margem de 4 módulos, como pede a norma)
  function svg(texto, { tamanho = 160, rotulo = "" } = {}) {
    const m = gerar(texto);
    const n = m.length + 8;
    let caminho = "";
    m.forEach((linha, y) => linha.forEach((escuro, x) => { if (escuro) caminho += `M${x + 4},${y + 4}h1v1h-1z`; }));
    return `<svg class="qr" role="img" aria-label="QR Code ${rotulo || texto}" width="${tamanho}" height="${tamanho}" viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="#fff"/><path d="${caminho}" fill="#111"/></svg>`;
  }

  return { gerar, svg };
})();
