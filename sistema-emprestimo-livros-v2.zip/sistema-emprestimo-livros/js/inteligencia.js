// ===================== RECOMENDAÇÃO E BUSCA POR SIGNIFICADO =====================
// Tudo roda no navegador, sem depender de IA paga:
// 1) Recomendador: pontuação ponderada por atributos dos livros, histórico e preferências.
//    Quando há leitores suficientes, ativa também a filtragem colaborativa ("quem leu X também leu Y").
// 2) BuscaSemantica: interpreta a intenção do texto (temas, gênero, tamanho, série, disponibilidade).

function juntarLista(itens) {
  if (itens.length <= 1) return itens.join("");
  return itens.slice(0, -1).join(", ") + " e " + itens[itens.length - 1];
}

function categoriaTamanho(paginas) {
  if (!paginas) return "";
  if (paginas <= TAMANHO.curtoAte) return "curto";
  if (paginas >= TAMANHO.longoAPartirDe) return "longo";
  return "medio";
}

const NOME_TAMANHO = { curto: "leitura curta", medio: "tamanho médio", longo: "leitura longa" };

const Recomendador = {
  // Mínimo de leitores com 2+ livros para ligar a filtragem colaborativa
  MIN_LEITORES_COLABORATIVO: 5,
  PAGINAS_POR_MINUTO: 0.66, // ~40 páginas por hora

  diasParaLer(livro, minutosPorDia) {
    if (!livro.paginas || !minutosPorDia) return 0;
    return Math.max(1, Math.ceil(livro.paginas / (minutosPorDia * this.PAGINAS_POR_MINUTO)));
  },

  // Semelhança entre dois livros: temas em comum (Jaccard), mesmo autor, mesma série e gênero
  similaridade(a, b) {
    if (!a || !b || a.id === b.id) return { valor: 0, temasComuns: [], mesmoAutor: false, mesmaSerie: false };
    const ta = new Set(a.temas || []);
    const comuns = (b.temas || []).filter(t => ta.has(t));
    const uniao = new Set([...(a.temas || []), ...(b.temas || [])]).size || 1;
    const mesmoAutor = normalizar(a.autor) === normalizar(b.autor);
    const mesmaSerie = !!a.serie && a.serie === b.serie;
    const valor = (comuns.length / uniao) * 6 + (mesmoAutor ? 1.5 : 0) + (mesmaSerie ? 2 : 0) + (a.genero === b.genero ? 0.8 : 0);
    return { valor, temasComuns: comuns, mesmoAutor, mesmaSerie };
  },

  parecidos(bib, livro, limite = 4) {
    return bib.livros
      .filter(l => l.id !== livro.id)
      .map(l => ({ livro: l, sim: this.similaridade(livro, l) }))
      .filter(x => x.sim.valor > 0.8)
      .sort((x, y) => y.sim.valor - x.sim.valor)
      .slice(0, limite);
  },

  // Matriz de co-leitura: para cada par de livros, quantos leitores diferentes pegaram os dois
  coLeitura(bib) {
    const porUsuario = new Map();
    bib.emprestimos.forEach(e => {
      if (!porUsuario.has(e.usuarioId)) porUsuario.set(e.usuarioId, new Set());
      porUsuario.get(e.usuarioId).add(e.livroId);
    });
    const matriz = new Map();
    let leitoresComHistorico = 0;
    porUsuario.forEach(ids => {
      const lista = [...ids];
      if (lista.length >= 2) leitoresComHistorico++;
      lista.forEach(a => lista.forEach(b => {
        if (a === b) return;
        if (!matriz.has(a)) matriz.set(a, new Map());
        matriz.get(a).set(b, (matriz.get(a).get(b) || 0) + 1);
      }));
    });
    return { matriz, leitoresComHistorico, ativa: leitoresComHistorico >= this.MIN_LEITORES_COLABORATIVO };
  },

  // perfil: { usuarioId, preferencias, lidos (Set de ids), notas (Map id->nota), excluir (Set) }
  recomendar(bib, perfil, limite = 8) {
    const prefs = perfil.preferencias || {};
    const lidos = perfil.lidos || new Set();
    const notas = perfil.notas || new Map();
    const excluir = perfil.excluir || new Set();
    const livrosLidos = bib.livros.filter(l => lidos.has(l.id));
    const gostou = livrosLidos.filter(l => (notas.get(l.id) || 4) >= 3);
    const naoGostou = livrosLidos.filter(l => (notas.get(l.id) || 4) <= 2);
    const co = this.coLeitura(bib);
    const temSinais = gostou.length || (prefs.generos || []).length || (prefs.temas || []).length;
    const popularidade = new Map();
    bib.emprestimos.forEach(e => popularidade.set(e.livroId, (popularidade.get(e.livroId) || 0) + 1));
    bib.reservas.forEach(r => popularidade.set(r.livroId, (popularidade.get(r.livroId) || 0) + 0.5));

    const resultados = bib.livros
      .filter(l => !lidos.has(l.id) && !excluir.has(l.id))
      .map(livro => {
        const motivos = []; // { peso, texto, tipo }
        const chips = [];
        let score = 0;

        if ((prefs.generos || []).includes(livro.genero)) {
          score += 3;
          motivos.push({ peso: 3, tipo: "genero", texto: `É ${livro.genero.toLowerCase()}, um dos gêneros de que você gosta.` });
          chips.push(livro.genero);
        }
        const temasPref = (livro.temas || []).filter(t => (prefs.temas || []).includes(t));
        if (temasPref.length) {
          score += 2 * temasPref.length;
          motivos.push({ peso: 2 * temasPref.length + 0.5, tipo: "temas", texto: `Fala de ${juntarLista(temasPref)}, ${temasPref.length > 1 ? "temas" : "tema"} que você quer explorar.` });
          temasPref.forEach(t => chips.push(t));
        }

        // Semelhança com o que a pessoa gostou (o motivo mais forte vira a justificativa)
        let melhor = null;
        gostou.forEach(l => {
          const s = this.similaridade(l, livro);
          let valor = s.valor;
          if (s.mesmaSerie) valor += 2.5; // continuar uma série que a pessoa começou
          if (!melhor || valor > melhor.valor) melhor = { valor, base: l, s };
        });
        if (melhor && melhor.valor > 1) {
          score += melhor.valor;
          const { base, s } = melhor;
          let texto;
          if (s.mesmaSerie) texto = `Você leu ${base.titulo}. ${livro.titulo} continua a série ${livro.serie}.`;
          else if (s.temasComuns.length >= 2) texto = `Você gostou de ${base.titulo}. Talvez goste de ${livro.titulo}, porque ambos exploram ${juntarLista(s.temasComuns.slice(0, 3))}.`;
          else if (s.mesmoAutor) texto = `Você gostou de ${base.titulo}. ${livro.titulo} é do mesmo autor, ${livro.autor}.`;
          else if (s.temasComuns.length === 1) texto = `Você gostou de ${base.titulo}. ${livro.titulo} também fala de ${s.temasComuns[0]}.`;
          else texto = `Tem a mesma pegada de ${base.titulo}.`;
          motivos.push({ peso: melhor.valor + 1, tipo: "similar", texto, baseId: base.id });
        }

        naoGostou.forEach(l => { score -= this.similaridade(l, livro).valor * 0.7; });

        // Filtragem colaborativa (só quando há dados suficientes)
        if (co.ativa) {
          let melhorCo = null;
          gostou.forEach(l => {
            const n = (co.matriz.get(l.id) || new Map()).get(livro.id) || 0;
            if (n >= 2 && (!melhorCo || n > melhorCo.n)) melhorCo = { n, base: l };
          });
          if (melhorCo) {
            const bonus = 1.2 * Math.min(melhorCo.n, 4);
            score += bonus;
            motivos.push({ peso: bonus, tipo: "colaborativo", texto: `${melhorCo.n} leitores que pegaram ${melhorCo.base.titulo} também pegaram este.` });
          }
        }

        // Tamanho e tempo de leitura
        const cat = categoriaTamanho(livro.paginas);
        if (prefs.tamanho && cat) {
          if (cat === prefs.tamanho) { score += 1.5; chips.push(NOME_TAMANHO[cat]); }
          else if ((cat === "longo" && prefs.tamanho === "curto") || (cat === "curto" && prefs.tamanho === "longo")) score -= 2.5;
          else score -= 0.8;
        }
        if (prefs.series === "sim" && livro.serie) { score += 1; chips.push("série"); }
        if (prefs.series === "nao" && livro.serie && !(melhor && melhor.s.mesmaSerie)) score -= 1.5;
        const dias = this.diasParaLer(livro, prefs.minutosPorDia);
        if (dias) chips.push(`≈ ${dias} dia${dias > 1 ? "s" : ""} no seu ritmo`);

        const { media, total } = bib.mediaAvaliacao(livro.id);
        if (total >= 2) score += (media - 3) * 0.6;
        if (livro.disponivel) score += 0.3;
        score += Math.log1p(popularidade.get(livro.id) || 0) * (temSinais ? 0.2 : 1);

        if (!temSinais) {
          motivos.push({ peso: 1, tipo: "popular", texto: total ? `Um dos mais procurados, com nota média ${media.toFixed(1)}.` : "Um dos títulos mais procurados da biblioteca." });
        }

        motivos.sort((a, b) => b.peso - a.peso);
        return { livro, score, motivo: motivos[0] ? motivos[0].texto : "", motivos, chips: [...new Set(chips)].slice(0, 4), dias };
      })
      .filter(r => r.motivos.length && r.score > 0.5)
      .sort((a, b) => b.score - a.score);

    return { resultados: resultados.slice(0, limite), colaborativo: co };
  }
};

// ---------- Busca por significado ----------

const PALAVRAS_VAZIAS = new Set(("quero queria gostaria procuro procurando livro livros um uma uns umas que fale fala falem sobre de do da dos das " +
  "e o a os as com para pra por mas nao seja muito tao algo alguma algum me eu tipo ler leitura historia historias tenha tem " +
  "mais menos bem bom boa coisa seja assim isso esse essa este esta sem").split(" "));

const BuscaSemantica = {
  interpretar(texto, bib) {
    const q = " " + normalizar(texto).replace(/[^\w\s+-]/g, " ").replace(/\s+/g, " ") + " ";
    const tokens = q.trim().split(" ").filter(Boolean);
    const r = { temas: [], generos: [], tamanho: "", series: "", disponivel: false, parecidoCom: null, palavras: [] };
    if (!q.trim()) return r;

    // Temas: expressões conhecidas + raiz da palavra (recomeços → recomeço, amadurecendo → amadurecimento)
    Object.entries(TEMAS).forEach(([tema, chaves]) => {
      const achou = chaves.some(k => {
        if (k.startsWith(" ")) return q.includes(k);
        if (q.includes(" " + k + " ")) return true;               // palavra exata
        if (k.includes(" ")) return q.includes(" " + k);          // expressão
        if (k.length < 6) return false;
        return tokens.some(t => t.length >= 6 && t.slice(0, 6) === k.slice(0, 6));
      });
      if (achou) r.temas.push(tema);
    });
    // "amor" é muito genérico: só conta se for o único tema ou aparecer escrito
    if (r.temas.length > 1 && r.temas.includes("amor") && !/ amor /.test(q)) r.temas = r.temas.filter(t => t !== "amor");

    Object.entries(GENEROS_SINONIMOS).forEach(([g, chaves]) => {
      if (chaves.some(k => q.includes(" " + k + " ") || (k.includes(" ") && q.includes(" " + k)))) r.generos.push(g);
    });
    // "romance" sozinho também é usado como "livro"; se há outro gênero, ignora
    if (r.generos.length > 1) r.generos = r.generos.filter(g => g !== "Romance" || / romance romantico| romantic/.test(q));

    // Tamanho
    if (/ (curto|curtinho|curtos|pequeno|rapido de ler|leitura rapida|poucas paginas|leve de ler|ler num fim de semana) /.test(q) ||
        /(nao|nada|nem|sem) (seja |for |muito |tao |)(muito |tao |)(longo|grande|extenso|comprido)/.test(q)) {
      r.tamanho = "curto";
    } else if (/ (longo|grande|extenso|calhamaco|bem longo|muitas paginas) /.test(q)) {
      r.tamanho = "longo";
    }

    // Série
    if (/(livro unico|sem continuacao|standalone|nao seja (de )?serie|sem serie|volume unico)/.test(q)) r.series = "nao";
    else if (/ (serie|saga|trilogia|continuacao|varios volumes) /.test(q)) r.series = "sim";

    if (/ (disponivel|disponiveis|pegar agora|pegar hoje|tem agora) /.test(q)) r.disponivel = true;

    // "parecido com <título>"
    if (bib && /(parecid|semelhante|igual a|tipo o |tipo a |estilo de|como o livro|no estilo)/.test(q)) {
      const candidatos = bib.livros
        .map(l => ({ l, t: normalizar(l.titulo).replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim() }))
        .filter(x => x.t.length >= 3 && q.includes(" " + x.t))
        .sort((a, b) => b.t.length - a.t.length);
      if (candidatos.length) r.parecidoCom = candidatos[0].l;
    }

    const usadas = new Set();
    r.temas.forEach(t => TEMAS[t].forEach(k => k.split(" ").forEach(w => usadas.add(w))));
    r.palavras = tokens.filter(t => t.length >= 4 && !PALAVRAS_VAZIAS.has(t) && !usadas.has(t));
    return r;
  },

  // Interpretação vazia: nada que a busca por significado tenha entendido
  vazia(i) {
    return !i.temas.length && !i.generos.length && !i.tamanho && !i.series && !i.parecidoCom && !i.disponivel;
  },

  buscar(bib, texto, { limite = 24 } = {}) {
    const i = this.interpretar(texto, bib);
    const resultados = bib.livros.map(livro => {
      let score = 0;
      const motivos = [];
      const temasLivro = livro.temas || [];
      const temasComuns = i.temas.filter(t => temasLivro.includes(t));
      if (temasComuns.length) {
        score += 3 * temasComuns.length;
        motivos.push(`fala de ${juntarLista(temasComuns)}`);
      }
      if (i.generos.includes(livro.genero)) {
        score += 2.5;
        motivos.push(livro.genero.toLowerCase());
      }
      if (i.parecidoCom) {
        if (livro.id === i.parecidoCom.id) return null;
        const s = Recomendador.similaridade(i.parecidoCom, livro);
        if (s.valor > 1) {
          score += s.valor;
          motivos.push(s.temasComuns.length ? `como ${i.parecidoCom.titulo}, explora ${juntarLista(s.temasComuns.slice(0, 3))}` : `mesmo estilo de ${i.parecidoCom.titulo}`);
        }
      }
      const textoLivro = normalizar(`${livro.titulo} ${livro.autor} ${livro.sinopse} ${temasLivro.join(" ")}`);
      const palavrasAchadas = i.palavras.filter(p => textoLivro.includes(p.length > 6 ? p.slice(0, 6) : p));
      if (palavrasAchadas.length) {
        score += 1.2 * palavrasAchadas.length;
        if (!motivos.length) motivos.push(`menciona “${palavrasAchadas.slice(0, 2).join("”, “")}”`);
      }

      // Filtros combinados: tamanho, série e disponibilidade
      const cat = categoriaTamanho(livro.paginas);
      if (i.tamanho) {
        if (i.tamanho === "curto" && cat === "longo") return null;
        if (i.tamanho === "longo" && cat === "curto") return null;
        if (cat === i.tamanho) { score += 1.5; motivos.push(`${livro.paginas} páginas (${NOME_TAMANHO[cat]})`); }
        else score -= 1;
      }
      if (i.series === "nao" && livro.serie) return null;
      if (i.series === "sim") { if (livro.serie) { score += 1; motivos.push(`série ${livro.serie}`); } else score -= 1; }
      if (i.disponivel && !livro.disponivel) return null;
      if (score <= 0.5) return null;
      return { livro, score, motivos };
    }).filter(Boolean).sort((a, b) => b.score - a.score || (b.livro.disponivel - a.livro.disponivel));
    return { interpretacao: i, resultados: resultados.slice(0, limite) };
  }
};

// ---------- Perfil de leitura (usuário logado ou visitante) ----------

// O visitante também pode experimentar as recomendações: as escolhas dele ficam só neste navegador
const PerfilVisitante = {
  CHAVE: "biblioteca-visitante",
  carregar() {
    try {
      const d = JSON.parse(localStorage.getItem(this.CHAVE));
      if (d) return { preferencias: d.preferencias || null, lidos: d.lidos || [] };
    } catch (e) { /* sem armazenamento */ }
    return this._memoria || { preferencias: null, lidos: [] };
  },
  salvar(dados) {
    this._memoria = dados;
    try { localStorage.setItem(this.CHAVE, JSON.stringify(dados)); } catch (e) { /* sem armazenamento */ }
  }
};

function perfilDeLeitura(bib) {
  const u = bib.usuarioLogado;
  if (u) {
    const notas = new Map(bib.avaliacoes.filter(a => a.usuarioId === u.id).map(a => [a.livroId, a.nota]));
    const excluir = new Set(bib.emprestimos.filter(e => e.usuarioId === u.id && e.ativo).map(e => e.livroId));
    return { usuarioId: u.id, preferencias: u.preferencias, lidos: bib.livrosLidosDe(u.id), notas, excluir };
  }
  const v = PerfilVisitante.carregar();
  return { usuarioId: null, preferencias: v.preferencias, lidos: new Set(v.lidos), notas: new Map(), excluir: new Set() };
}
