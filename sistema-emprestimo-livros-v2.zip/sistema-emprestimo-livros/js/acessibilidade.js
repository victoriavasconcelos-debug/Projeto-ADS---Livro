// ===================== ACESSIBILIDADE E LEITURA INCLUSIVA =====================
// Preferências aplicadas na página inteira. Ficam salvas no navegador e, se a pessoa
// estiver logada, também no cadastro dela: ao entrar em outro computador, a plataforma
// adapta a experiência automaticamente.

const ACESSIBILIDADE_PADRAO = {
  fonte: 100,             // % do tamanho do texto
  espacamento: "normal",  // normal | amplo
  contraste: "padrao",    // padrao | alto | escuro
  fonteLeitura: false,    // fonte de leitura facilitada (mais espaçada)
  reduzirAnimacoes: false,
  destacarFoco: false,
  leituraVoz: false,      // mostra o botão "Ouvir" em todos os cards
  velocidadeVoz: 1
};

const Acessibilidade = {
  CHAVE: "biblioteca-acessibilidade",
  config: { ...ACESSIBILIDADE_PADRAO },

  carregar() {
    let salvo = null;
    try { salvo = JSON.parse(localStorage.getItem(this.CHAVE)); } catch (e) { /* sem armazenamento */ }
    if (salvo) {
      this.config = { ...ACESSIBILIDADE_PADRAO, ...salvo };
    } else {
      // Primeira visita: respeita a preferência do sistema operacional por menos movimento
      try {
        if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) this.config.reduzirAnimacoes = true;
      } catch (e) { /* ignorar */ }
    }
    this.aplicar();
  },

  salvar(bib) {
    try { localStorage.setItem(this.CHAVE, JSON.stringify(this.config)); } catch (e) { /* sem armazenamento */ }
    if (bib) bib.salvarAcessibilidadeDoUsuario({ ...this.config });
  },

  definir(chave, valor, bib) {
    this.config[chave] = valor;
    this.aplicar();
    this.salvar(bib);
  },

  restaurar(bib) {
    this.config = { ...ACESSIBILIDADE_PADRAO };
    this.aplicar();
    this.salvar(bib);
  },

  // Chamado ao entrar: se o usuário tem preferências salvas, aplica sem ele precisar ajustar de novo
  aplicarDoUsuario(usuario) {
    if (!usuario || !usuario.acessibilidade) return false;
    this.config = { ...ACESSIBILIDADE_PADRAO, ...usuario.acessibilidade };
    this.aplicar();
    try { localStorage.setItem(this.CHAVE, JSON.stringify(this.config)); } catch (e) { /* ignorar */ }
    return true;
  },

  personalizado() {
    return Object.keys(ACESSIBILIDADE_PADRAO).some(k => k !== "velocidadeVoz" && this.config[k] !== ACESSIBILIDADE_PADRAO[k]);
  },

  aplicar() {
    const raiz = document.documentElement;
    const c = this.config;
    raiz.style.fontSize = `${c.fonte}%`;
    raiz.classList.toggle("a11y-amplo", c.espacamento === "amplo");
    raiz.classList.toggle("a11y-alto-contraste", c.contraste === "alto");
    raiz.classList.toggle("a11y-escuro", c.contraste === "escuro");
    raiz.classList.toggle("a11y-fonte-leitura", !!c.fonteLeitura);
    raiz.classList.toggle("a11y-sem-animacao", !!c.reduzirAnimacoes);
    raiz.classList.toggle("a11y-foco", !!c.destacarFoco);
    raiz.classList.toggle("a11y-voz", !!c.leituraVoz);
  }
};

// Leitura em voz alta (síntese de fala do próprio navegador)
const Voz = {
  disponivel() {
    return typeof window !== "undefined" && "speechSynthesis" in window && typeof SpeechSynthesisUtterance === "function";
  },

  falar(texto) {
    if (!this.disponivel()) {
      mensagem("Seu navegador não tem leitura em voz alta.", true);
      return;
    }
    window.speechSynthesis.cancel();
    const fala = new SpeechSynthesisUtterance(texto);
    fala.lang = "pt-BR";
    fala.rate = Acessibilidade.config.velocidadeVoz || 1;
    const voz = window.speechSynthesis.getVoices().find(v => /^pt(-|_)BR/i.test(v.lang)) ||
      window.speechSynthesis.getVoices().find(v => /^pt/i.test(v.lang));
    if (voz) fala.voice = voz;
    window.speechSynthesis.speak(fala);
  },

  parar() {
    if (this.disponivel()) window.speechSynthesis.cancel();
  },

  textoDoLivro(bib, livro) {
    const { media, total } = bib.mediaAvaliacao(livro.id);
    return [
      `${livro.titulo}, de ${livro.autor}.`,
      `Gênero: ${livro.genero}.`,
      livro.paginas ? `${livro.paginas} páginas.` : "",
      livro.sinopse,
      livro.disponivel ? `${livro.qtdDisponiveis} exemplar disponível.` : "Todos os exemplares estão emprestados.",
      total ? `Nota média ${media.toFixed(1).replace(".", ",")} de 5.` : "",
      livro.formatos.length > 1 ? `Também disponível em: ${livro.formatos.filter(f => f !== "impresso").map(f => FORMATOS[f]).join(", ")}.` : ""
    ].filter(Boolean).join(" ");
  }
};

// Descrição acessível da capa (texto alternativo mais rico que "capa do livro")
function descricaoCapa(livro) {
  return `Capa do livro ${livro.titulo}, de ${livro.autor}. ${livro.genero}${livro.temas && livro.temas.length ? ", sobre " + juntarLista(livro.temas.slice(0, 3)) : ""}.`;
}
