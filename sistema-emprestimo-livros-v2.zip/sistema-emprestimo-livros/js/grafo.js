// ===================== MAPA DE CONHECIMENTO =====================
// Grafo em que livros se ligam a temas e autores. O leitor explora as conexões
// e descobre caminhos entre leituras (ex.: Eu, Robô → ética → Frankenstein → solidão → O Pequeno Príncipe).
// Layout por simulação de forças, feito à mão em JavaScript e desenhado em SVG (sem bibliotecas externas).

const CORES_GENERO = {
  "Romance": "#d9467a", "Comédia romântica": "#f08a3c", "Drama": "#8b5cf6", "Suspense": "#334155",
  "Fantasia": "#0f9d8a", "Distopia": "#c2410c", "Ficção científica": "#2563eb", "Filosofia e ideias": "#a16207", "Outros": "#6b7280"
};

function aleatorioComSemente(semente) {
  let a = semente >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const MapaConhecimento = {
  LARGURA: 1000,
  ALTURA: 680,

  construir(bib, { genero = "" } = {}) {
    const livros = bib.livros.filter(l => (!genero || l.genero === genero) && (l.temas || []).length);
    const nos = new Map();
    const arestas = [];
    const add = (id, dados) => { if (!nos.has(id)) nos.set(id, { id, grau: 0, ...dados }); return nos.get(id); };
    const contagemAutor = {};
    livros.forEach(l => { contagemAutor[l.autor] = (contagemAutor[l.autor] || 0) + 1; });
    livros.forEach(l => {
      add("l:" + l.id, { tipo: "livro", rotulo: l.titulo, livroId: l.id, genero: l.genero });
      l.temas.forEach(t => {
        add("t:" + t, { tipo: "tema", rotulo: t });
        arestas.push({ a: "l:" + l.id, b: "t:" + t });
      });
      if (contagemAutor[l.autor] >= 2) {
        add("a:" + l.autor, { tipo: "autor", rotulo: l.autor });
        arestas.push({ a: "l:" + l.id, b: "a:" + l.autor });
      }
    });
    const adj = new Map([...nos.keys()].map(k => [k, new Set()]));
    arestas.forEach(e => {
      adj.get(e.a).add(e.b); adj.get(e.b).add(e.a);
      nos.get(e.a).grau++; nos.get(e.b).grau++;
    });
    // Temas que só aparecem em um livro poluem o mapa: some com eles (o livro continua ligado aos demais)
    [...nos.values()].filter(n => n.tipo === "tema" && n.grau < 2 && nos.size > 30).forEach(n => {
      adj.get(n.id).forEach(viz => { adj.get(viz).delete(n.id); nos.get(viz).grau--; });
      adj.delete(n.id); nos.delete(n.id);
    });
    const arestasFinais = arestas.filter(e => nos.has(e.a) && nos.has(e.b));
    this.layout([...nos.values()], arestasFinais, nos);
    return { nos, arestas: arestasFinais, adj };
  },

  layout(lista, arestas, mapa) {
    const W = this.LARGURA, H = this.ALTURA;
    const rnd = aleatorioComSemente(42);
    lista.forEach((n, i) => {
      const ang = (i / lista.length) * Math.PI * 2;
      const raio = n.tipo === "tema" ? 160 : 280;
      n.x = W / 2 + Math.cos(ang) * raio + (rnd() - 0.5) * 40;
      n.y = H / 2 + Math.sin(ang) * raio * 0.7 + (rnd() - 0.5) * 40;
      n.vx = 0; n.vy = 0;
    });
    const k = Math.sqrt((W * H) / Math.max(lista.length, 1)) * 0.62;
    for (let it = 0; it < 320; it++) {
      const temp = 1 - it / 320;
      for (let i = 0; i < lista.length; i++) {
        const a = lista[i];
        for (let j = i + 1; j < lista.length; j++) {
          const b = lista[j];
          let dx = a.x - b.x, dy = a.y - b.y;
          let d2 = dx * dx + dy * dy;
          if (d2 < 0.01) { dx = rnd() - 0.5; dy = rnd() - 0.5; d2 = 0.5; }
          const f = (k * k) / d2;
          a.vx += dx * f * 0.02; a.vy += dy * f * 0.02;
          b.vx -= dx * f * 0.02; b.vy -= dy * f * 0.02;
        }
      }
      arestas.forEach(e => {
        const a = mapa.get(e.a), b = mapa.get(e.b);
        const dx = b.x - a.x, dy = b.y - a.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - k * 0.75) * 0.02;
        a.vx += (dx / d) * f * d * 0.05; a.vy += (dy / d) * f * d * 0.05;
        b.vx -= (dx / d) * f * d * 0.05; b.vy -= (dy / d) * f * d * 0.05;
      });
      lista.forEach(n => {
        n.vx += (W / 2 - n.x) * 0.004;
        n.vy += (H / 2 - n.y) * 0.006;
        const v = Math.sqrt(n.vx * n.vx + n.vy * n.vy) || 1;
        const max = 18 * temp + 0.5;
        if (v > max) { n.vx = (n.vx / v) * max; n.vy = (n.vy / v) * max; }
        n.x = Math.min(W - 40, Math.max(40, n.x + n.vx));
        n.y = Math.min(H - 30, Math.max(30, n.y + n.vy));
        n.vx *= 0.55; n.vy *= 0.55;
      });
    }
  },

  // Menor caminho entre dois nós (busca em largura)
  caminho(adj, origem, destino) {
    if (!adj.has(origem) || !adj.has(destino)) return null;
    const anterior = new Map([[origem, null]]);
    const fila = [origem];
    while (fila.length) {
      const atual = fila.shift();
      if (atual === destino) break;
      adj.get(atual).forEach(v => { if (!anterior.has(v)) { anterior.set(v, atual); fila.push(v); } });
    }
    if (!anterior.has(destino)) return null;
    const c = [];
    for (let n = destino; n !== null; n = anterior.get(n)) c.unshift(n);
    return c;
  },

  // Livros a dois passos (que compartilham temas/autor), ordenados por quantas conexões em comum
  vizinhosDeLivro(grafo, idNo) {
    const conta = new Map();
    grafo.adj.get(idNo).forEach(meio => grafo.adj.get(meio).forEach(l => {
      if (l !== idNo && l.startsWith("l:")) {
        if (!conta.has(l)) conta.set(l, []);
        conta.get(l).push(grafo.nos.get(meio).rotulo);
      }
    }));
    return [...conta.entries()].sort((a, b) => b[1].length - a[1].length);
  }
};

// ---------- Interface do mapa ----------

const MapaUI = {
  grafo: null,
  selecionado: null,
  caminhoAtual: null,
  genero: "",
  zoom: { x: 0, y: 0, k: 1 },

  render(bib) {
    const svg = document.getElementById("mapa-svg");
    if (!svg) return;
    this.grafo = MapaConhecimento.construir(bib, { genero: this.genero });
    if (this.selecionado && !this.grafo.nos.has(this.selecionado)) this.selecionado = null;
    this.desenhar();
    this.painel(bib);
  },

  desenhar() {
    const svg = document.getElementById("mapa-svg");
    const g = this.grafo;
    const foco = new Set();
    const arestasCaminho = new Set();
    if (this.caminhoAtual) {
      this.caminhoAtual.forEach(n => foco.add(n));
      for (let i = 0; i + 1 < this.caminhoAtual.length; i++) {
        arestasCaminho.add(this.caminhoAtual[i] + "|" + this.caminhoAtual[i + 1]);
        arestasCaminho.add(this.caminhoAtual[i + 1] + "|" + this.caminhoAtual[i]);
      }
    } else if (this.selecionado) {
      foco.add(this.selecionado);
      g.adj.get(this.selecionado).forEach(v => foco.add(v));
    }
    const temFoco = foco.size > 0;
    const raio = n => n.tipo === "tema" ? 7 + Math.min(n.grau, 10) * 1.1 : n.tipo === "autor" ? 8 : 6;
    let html = `<g transform="translate(${this.zoom.x},${this.zoom.y}) scale(${this.zoom.k})">`;
    g.arestas.forEach(e => {
      const a = g.nos.get(e.a), b = g.nos.get(e.b);
      const noCaminho = arestasCaminho.has(e.a + "|" + e.b);
      const ativa = noCaminho || (!this.caminhoAtual && temFoco && (e.a === this.selecionado || e.b === this.selecionado));
      html += `<line x1="${a.x.toFixed(1)}" y1="${a.y.toFixed(1)}" x2="${b.x.toFixed(1)}" y2="${b.y.toFixed(1)}" class="aresta ${ativa ? "ativa" : ""} ${noCaminho ? "caminho" : ""} ${temFoco && !ativa ? "apagada" : ""}"/>`;
    });
    g.nos.forEach(n => {
      const ativo = !temFoco || foco.has(n.id);
      const cor = n.tipo === "livro" ? CORES_GENERO[n.genero] || "#6b7280" : n.tipo === "autor" ? "#475569" : "#c9a227";
      const mostrarRotulo = n.tipo !== "livro" ? (ativo || !temFoco) : (temFoco && ativo);
      const r = raio(n);
      const rotulo = n.rotulo.length > 26 ? n.rotulo.slice(0, 24) + "…" : n.rotulo;
      html += `<g class="no no-${n.tipo} ${ativo ? "" : "apagado"} ${n.id === this.selecionado ? "selecionado" : ""}" data-id="${esc(n.id)}" tabindex="0" role="button" aria-label="${esc((n.tipo === "livro" ? "Livro " : n.tipo === "autor" ? "Autor " : "Tema ") + n.rotulo)}" transform="translate(${n.x.toFixed(1)},${n.y.toFixed(1)})">
        <title>${esc(n.rotulo)}</title>
        ${n.tipo === "autor" ? `<rect x="${-r}" y="${-r}" width="${2 * r}" height="${2 * r}" rx="3" fill="${cor}"/>` : `<circle r="${r}" fill="${cor}"/>`}
        ${mostrarRotulo ? `<text y="${n.tipo === "livro" ? -r - 5 : r + 13}" class="rotulo-${n.tipo}">${esc(rotulo)}</text>` : ""}
      </g>`;
    });
    html += "</g>";
    svg.innerHTML = html;
  },

  painel(bib) {
    const el = document.getElementById("mapa-detalhe");
    const g = this.grafo;
    if (this.caminhoAtual) {
      const passos = this.caminhoAtual.map(id => {
        const n = g.nos.get(id);
        return n.tipo === "livro" ? `<b>${esc(n.rotulo)}</b>` : `<span class="chip-tema">${esc(n.rotulo)}</span>`;
      });
      el.innerHTML = `<h3>Como esses livros se conectam</h3><p class="caminho-texto">${passos.join(' <span class="seta">→</span> ')}</p>
        <p class="dica">${Math.floor(this.caminhoAtual.length / 2)} salto(s) de um livro ao outro passando por temas e autores em comum.</p>
        <button class="pequeno secundario" onclick="MapaUI.limpar()">Limpar caminho</button>`;
      return;
    }
    if (!this.selecionado) {
      const temas = [...g.nos.values()].filter(n => n.tipo === "tema").sort((a, b) => b.grau - a.grau).slice(0, 8);
      el.innerHTML = `<h3>Explore o acervo pelas ideias</h3>
        <p>Cada ponto colorido é um livro; os pontos dourados são temas e os quadrados, autores. Clique (ou use Tab e Enter) em qualquer um para ver suas conexões.</p>
        <p class="dica">Temas com mais conexões:</p>
        <div class="chips">${temas.map(t => `<button class="chip-tema" onclick="MapaUI.selecionar('${esc(t.id)}')">${esc(t.rotulo)} <small>${t.grau}</small></button>`).join("")}</div>
        <div class="legenda">${Object.entries(CORES_GENERO).filter(([gn]) => [...g.nos.values()].some(n => n.genero === gn)).map(([gn, c]) => `<span><i style="background:${c}"></i>${esc(gn)}</span>`).join("")}</div>`;
      return;
    }
    const n = g.nos.get(this.selecionado);
    const vizinhos = [...g.adj.get(n.id)].map(id => g.nos.get(id));
    if (n.tipo === "livro") {
      const livro = bib.livros.find(l => l.id === n.livroId);
      const parecidos = MapaConhecimento.vizinhosDeLivro(g, n.id).slice(0, 5);
      el.innerHTML = `<h3>${esc(n.rotulo)}</h3><p class="dica">${esc(livro ? livro.autor + " · " + livro.genero : "")}</p>
        <p>Conecta-se a:</p><div class="chips">${vizinhos.map(v => `<button class="chip-tema" onclick="MapaUI.selecionar('${esc(v.id)}')">${esc(v.rotulo)}</button>`).join("")}</div>
        ${parecidos.length ? `<p>Leituras próximas no mapa:</p><ul class="lista-mapa">${parecidos.map(([id, via]) => `<li><a href="#" onclick="MapaUI.selecionar('${esc(id)}');return false">${esc(g.nos.get(id).rotulo)}</a> <span class="sub">via ${esc(juntarLista(via.slice(0, 3)))}</span></li>`).join("")}</ul>` : ""}
        <p><button class="pequeno" onclick="abrirLivro(${n.livroId})">Abrir livro</button> <button class="pequeno secundario" onclick="MapaUI.limpar()">Voltar à visão geral</button></p>`;
    } else {
      el.innerHTML = `<h3>${n.tipo === "tema" ? "Tema" : "Autor"}: ${esc(n.rotulo)}</h3>
        <p>${vizinhos.length} livro(s) ligados a ${n.tipo === "tema" ? "este tema" : "este autor"}:</p>
        <ul class="lista-mapa">${vizinhos.map(v => `<li><a href="#" onclick="MapaUI.selecionar('${esc(v.id)}');return false">${esc(v.rotulo)}</a></li>`).join("")}</ul>
        <p><button class="pequeno secundario" onclick="MapaUI.limpar()">Voltar à visão geral</button></p>`;
    }
  },

  selecionar(id) {
    this.caminhoAtual = null;
    this.selecionado = id;
    this.desenhar();
    this.painel(biblioteca);
  },

  limpar() {
    this.selecionado = null;
    this.caminhoAtual = null;
    document.getElementById("mapa-de").value = "";
    document.getElementById("mapa-ate").value = "";
    this.desenhar();
    this.painel(biblioteca);
  },

  tracarCaminho() {
    const de = document.getElementById("mapa-de").value;
    const ate = document.getElementById("mapa-ate").value;
    if (!de || !ate || de === ate) { mensagem("Escolha dois livros diferentes.", true); return; }
    if (!this.grafo.nos.has("l:" + de) || !this.grafo.nos.has("l:" + ate)) {
      this.genero = "";
      document.getElementById("mapa-genero").value = "";
      this.grafo = MapaConhecimento.construir(biblioteca, {});
    }
    const c = MapaConhecimento.caminho(this.grafo.adj, "l:" + de, "l:" + ate);
    if (!c) { mensagem("Não há conexão entre esses livros no mapa.", true); return; }
    this.selecionado = null;
    this.caminhoAtual = c;
    this.desenhar();
    this.painel(biblioteca);
  },

  ligarEventos() {
    const svg = document.getElementById("mapa-svg");
    let arrastando = null;
    svg.addEventListener("click", ev => {
      const no = ev.target.closest(".no");
      if (no && !(arrastando && arrastando.moveu)) this.selecionar(no.dataset.id);
    });
    svg.addEventListener("keydown", ev => {
      const no = ev.target.closest(".no");
      if (no && (ev.key === "Enter" || ev.key === " ")) { ev.preventDefault(); this.selecionar(no.dataset.id); setTimeout(() => { const n = svg.querySelector(`[data-id="${CSS.escape(no.dataset.id)}"]`); if (n) n.focus(); }, 0); }
    });
    svg.addEventListener("wheel", ev => {
      ev.preventDefault();
      const rect = svg.getBoundingClientRect();
      const px = ((ev.clientX - rect.left) / rect.width) * MapaConhecimento.LARGURA;
      const py = ((ev.clientY - rect.top) / rect.height) * MapaConhecimento.ALTURA;
      const fator = ev.deltaY < 0 ? 1.15 : 1 / 1.15;
      const k = Math.min(4, Math.max(0.6, this.zoom.k * fator));
      this.zoom.x = px - ((px - this.zoom.x) * k) / this.zoom.k;
      this.zoom.y = py - ((py - this.zoom.y) * k) / this.zoom.k;
      this.zoom.k = k;
      this.desenhar();
    }, { passive: false });
    svg.addEventListener("pointerdown", ev => {
      arrastando = { x: ev.clientX, y: ev.clientY, zx: this.zoom.x, zy: this.zoom.y, moveu: false };
    });
    window.addEventListener("pointermove", ev => {
      if (!arrastando) return;
      const rect = svg.getBoundingClientRect();
      const esc2 = MapaConhecimento.LARGURA / rect.width;
      const dx = (ev.clientX - arrastando.x) * esc2, dy = (ev.clientY - arrastando.y) * esc2;
      if (Math.abs(dx) + Math.abs(dy) > 4) arrastando.moveu = true;
      if (arrastando.moveu) { this.zoom.x = arrastando.zx + dx; this.zoom.y = arrastando.zy + dy; this.desenhar(); }
    });
    window.addEventListener("pointerup", () => { setTimeout(() => { arrastando = null; }, 0); });
  },

  ajustarZoom(fator) {
    if (fator === 0) this.zoom = { x: 0, y: 0, k: 1 };
    else {
      const k = Math.min(4, Math.max(0.6, this.zoom.k * fator));
      const cx = MapaConhecimento.LARGURA / 2, cy = MapaConhecimento.ALTURA / 2;
      this.zoom.x = cx - ((cx - this.zoom.x) * k) / this.zoom.k;
      this.zoom.y = cy - ((cy - this.zoom.y) * k) / this.zoom.k;
      this.zoom.k = k;
    }
    this.desenhar();
  }
};
