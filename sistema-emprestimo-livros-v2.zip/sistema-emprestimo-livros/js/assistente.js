// ===================== LIA, ASSISTENTE DE LEITURA =====================
// Versão baseada em regras: identifica a intenção da pergunta e consulta os dados reais
// da biblioteca. Ela nunca inventa disponibilidade, prazos ou informações sobre livros:
// tudo o que responde vem da classe Biblioteca (o "banco de dados" do sistema).
// Num passo futuro, as mesmas consultas podem virar "ferramentas" de um modelo de linguagem.

const TITULOS_AMBIGUOS = new Set(["um dia"]);

const Lia = {
  nome: "Lia",

  sugestoesIniciais(perfil) {
    const base = ["Quais livros de suspense estão disponíveis?", "Quero começar a ler ficção científica. Por onde começo?", "Como faço para reservar um exemplar?"];
    if (perfil === "usuario") return ["Tenho algum empréstimo próximo do vencimento?", "Quais livros parecidos com os que já li estão disponíveis?", ...base.slice(0, 2)];
    return base;
  },

  livroMencionado(bib, q) {
    const achados = bib.livros
      .map(l => ({ l, t: normalizar(l.titulo).replace(/[^\w\s&]/g, " ").replace(/\s+/g, " ").trim() }))
      .filter(x => x.t.length >= 4 && (" " + q + " ").includes(" " + x.t + " "))
      .filter(x => !TITULOS_AMBIGUOS.has(x.t) || /livro|nicholls|"/.test(q))
      .sort((a, b) => b.t.length - a.t.length);
    return achados.length ? achados[0].l : null;
  },

  autorMencionado(bib, q) {
    const autores = [...new Set(bib.livros.map(l => l.autor))];
    return autores.find(a => {
      const n = normalizar(a);
      const sobrenome = n.split(" ").pop();
      return q.includes(n) || (sobrenome.length >= 5 && q.includes(sobrenome));
    }) || null;
  },

  statusLivro(bib, livro, usuarioId) {
    const fila = bib.filaDe(livro.id).length;
    const { media, total } = bib.mediaAvaliacao(livro.id);
    let s = livro.disponivel
      ? `${livro.qtdDisponiveis} de ${livro.exemplaresAtivos.length} exemplar(es) disponível(is)`
      : `todos os ${livro.exemplaresAtivos.length} exemplar(es) estão emprestados`;
    if (fila) s += `, ${fila} pessoa(s) na fila de reserva`;
    if (!livro.disponivel) {
      const prox = bib.emprestimosAtivosDe(livro.id).map(e => new Date(e.dataPrevista)).sort((a, b) => a - b)[0];
      if (prox) s += `; previsão de devolução mais próxima: ${prox.toLocaleDateString("pt-BR")}`;
    }
    if (total) s += `. Nota média ${media.toFixed(1)} (${total} avaliação${total > 1 ? "ões" : ""})`;
    if (usuarioId && livro.disponivel && !bib.podePegarAgora(livro, usuarioId)) s += ". Os exemplares livres estão reservados para a fila";
    return s + ".";
  },

  responder(bib, pergunta) {
    const q = normalizar(pergunta).replace(/[?!.,;:]/g, " ").replace(/\s+/g, " ").trim();
    const perfil = bib.perfil;
    const usuario = bib.usuarioLogado;
    const r = { texto: [], livros: [], sugestoes: [], fonte: true };
    const precisaEntrar = () => {
      r.texto.push("Para isso eu preciso saber quem você é: entre com sua matrícula no topo da página e me pergunte de novo.");
      r.fonte = false;
      return r;
    };
    const interp = BuscaSemantica.interpretar(pergunta, bib);
    const genero = interp.generos[0] || null;

    if (!q || /^(ajuda|help|menu|o que voce faz|o que voce sabe|quem e voce)/.test(q)) {
      r.texto.push("Oi! Eu sou a Lia, sua assistente de leitura. Respondo com base no catálogo e nos empréstimos reais da biblioteca. Posso, por exemplo:");
      r.texto.push("• dizer quais livros de um gênero estão disponíveis;\n• avisar se você tem empréstimo perto do vencimento;\n• sugerir por onde começar um gênero novo;\n• indicar livros parecidos com os que você já leu;\n• explicar como reservar, renovar e como funcionam as multas.");
      r.sugestoes = this.sugestoesIniciais(perfil);
      r.fonte = false;
      return r;
    }
    if (/^(oi|ola|bom dia|boa tarde|boa noite|e ai|hey)( lia)?$/.test(q)) {
      r.texto.push(`Olá${usuario ? ", " + usuario.nome.split(" ")[0] : ""}! Como posso ajudar na sua próxima leitura?`);
      r.sugestoes = this.sugestoesIniciais(perfil);
      r.fonte = false;
      return r;
    }
    if (/^(obrigad|valeu|brigad)/.test(q)) {
      r.texto.push("De nada! Boa leitura. 📖");
      r.fonte = false;
      return r;
    }

    // Prazos e empréstimos do usuário
    if (/(vencimento|vence|vencer|prazo|atrasad|meus emprestimos|meus livros|estou com|tenho algum emprestimo|devolver ate)/.test(q) && !/reserv/.test(q)) {
      if (perfil === "bibliotecario") {
        const atrasados = bib.emprestimos.filter(e => e.atrasado);
        const vencendo = bib.emprestimos.filter(e => e.ativo && !e.atrasado && e.diasRestantes <= 2);
        r.texto.push(`No momento há ${atrasados.length} empréstimo(s) atrasado(s) e ${vencendo.length} vencendo nos próximos 2 dias.`);
        atrasados.slice(0, 5).forEach(e => r.texto.push(`• ${bib.tituloDe(e)}, com ${bib.nomeDe(e)}: ${e.diasAtraso} dia(s) de atraso.`));
        return r;
      }
      if (!usuario) return precisaEntrar();
      const ativos = bib.emprestimos.filter(e => e.usuarioId === usuario.id && e.ativo)
        .sort((a, b) => new Date(a.dataPrevista) - new Date(b.dataPrevista));
      if (!ativos.length) {
        r.texto.push("Você não está com nenhum livro emprestado agora, então não há prazos correndo. 🙂");
        r.sugestoes = ["Quais livros parecidos com os que já li estão disponíveis?"];
        return r;
      }
      const proximos = ativos.filter(e => e.atrasado || e.diasRestantes <= 3);
      r.texto.push(proximos.length
        ? `Sim: ${proximos.length} empréstimo(s) pede(m) atenção.`
        : `Nenhum vence nos próximos 3 dias. Você está com ${ativos.length} livro(s):`);
      ativos.forEach(e => {
        const quando = e.atrasado
          ? `atrasado há ${e.diasAtraso} dia(s), multa atual de ${e.multa.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}`
          : `devolver até ${new Date(e.dataPrevista).toLocaleDateString("pt-BR")} (${e.diasRestantes <= 0 ? "hoje" : `faltam ${e.diasRestantes} dia(s)`})`;
        r.texto.push(`• ${bib.tituloDe(e)}: ${quando}.`);
      });
      if (ativos.some(e => !e.atrasado && e.renovacoes < MAX_RENOVACOES)) r.texto.push("Se precisar de mais tempo, você pode renovar em “Meus empréstimos”.");
      return r;
    }

    if (/multa/.test(q)) {
      r.texto.push(`A multa é de ${MULTA_POR_DIA.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })} por dia de atraso. Enquanto houver livro atrasado, novos empréstimos ficam bloqueados.`);
      if (usuario) {
        const total = bib.emprestimos.filter(e => e.usuarioId === usuario.id).reduce((s, e) => s + e.multa, 0);
        r.texto.push(total ? `Suas multas somam ${total.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}.` : "Você não tem multas. 👏");
      }
      return r;
    }

    if (/renov/.test(q)) {
      r.texto.push(`Cada empréstimo pode ser renovado até ${MAX_RENOVACOES} vezes, ganhando +${PRAZO_DIAS} dias, desde que não esteja atrasado e que ninguém esteja na fila de reserva do livro. É só clicar em “Renovar” em “Meus empréstimos”.`);
      return r;
    }

    const livro = this.livroMencionado(bib, q);

    if (/reserv|fila|lista de espera/.test(q)) {
      if (livro) {
        r.texto.push(`${livro.titulo}: ${this.statusLivro(bib, livro, usuario && usuario.id)}`);
        r.texto.push(livro.disponivel && (!usuario || bib.podePegarAgora(livro, usuario.id))
          ? "Como há exemplar livre, nem precisa reservar: é só clicar em Emprestar."
          : "Para entrar na fila, abra o livro e clique em “Reservar”. Quando um exemplar voltar, ele fica guardado para quem chegou primeiro.");
        r.livros.push({ livro });
        return r;
      }
      r.texto.push(`Quando todos os exemplares de um título estão emprestados, aparece o botão “Reservar” no card do livro. Você entra numa fila: quando um exemplar é devolvido, ele fica guardado para a primeira pessoa da fila. Cada leitor pode ter até ${MAX_RESERVAS} reservas ativas.`);
      if (usuario) {
        const minhas = bib.reservasDoUsuario(usuario.id);
        r.texto.push(minhas.length
          ? "Suas reservas: " + minhas.map(m => `${m.livro.titulo} (${m.pronta ? "já pode retirar!" : m.posicao + "º na fila"})`).join("; ") + "."
          : "Você não tem reservas ativas.");
      }
      return r;
    }

    if (/(como (faco|faço) para (pegar|emprestar)|como (pego|empresto)|como funciona o emprestimo)/.test(q)) {
      r.texto.push(`Entre com sua matrícula, escolha o livro no acervo e clique em “Emprestar”. O prazo é de ${PRAZO_DIAS} dias e cada pessoa pode ficar com até ${MAX_EMPRESTIMOS} livros ao mesmo tempo. A devolução é registrada no balcão, lendo o QR Code do exemplar.`);
      r.fonte = false;
      return r;
    }

    // Por onde começar um gênero
    if (/(por onde comec|comecar a ler|quero comecar|iniciante|nunca li|primeiro livro de|primeira leitura)/.test(q)) {
      if (!genero) {
        r.texto.push("Qual gênero você quer começar? Temos " + GENEROS.filter(g => g !== "Outros").join(", ").toLowerCase() + ".");
        r.sugestoes = ["Quero começar a ler fantasia", "Quero começar a ler suspense", "Quero começar a ler ficção científica"];
        return r;
      }
      const lidos = usuario ? bib.livrosLidosDe(usuario.id) : new Set();
      const candidatos = bib.livros.filter(l => l.genero === genero && !lidos.has(l.id));
      // Para quem está começando: livro único ou primeiro da série, mais curto, bem avaliado e disponível
      const primeiroDaSerie = l => !l.serie || !bib.livros.some(o => o.serie === l.serie && o.id < l.id);
      const pontua = l => (primeiroDaSerie(l) ? 2 : -3) + (l.paginas && l.paginas <= 400 ? 1.5 : 0) +
        (bib.mediaAvaliacao(l.id).media || 3.5) * 0.6 + (l.disponivel ? 1 : 0);
      const top = candidatos.sort((a, b) => pontua(b) - pontua(a)).slice(0, 3);
      if (!top.length) {
        r.texto.push(`Ainda não temos livros de ${genero.toLowerCase()} que você não tenha lido.`);
        return r;
      }
      r.texto.push(`Para começar em ${genero.toLowerCase()}, eu iria nestes (escolhi livros que abrem série ou são únicos, de tamanho tranquilo):`);
      top.forEach(l => r.livros.push({ livro: l, nota: `${l.paginas} páginas · ${l.disponivel ? "disponível agora" : "emprestado no momento"}${l.serie ? " · 1º da série " + l.serie : ""}` }));
      return r;
    }

    // Parecidos com o que já leu / recomendações
    if (/(parecid|semelhante|como os que (ja )?li|recomend|indica|sugere|sugestao|o que (eu )?(devo )?ler)/.test(q)) {
      if (!usuario) {
        if (perfil === "bibliotecario") { r.texto.push("Recomendações são pessoais: entre como usuário para eu usar o seu histórico."); return r; }
        r.texto.push("Sem login eu não conheço seu histórico, então vou pelos mais procurados. Entre com sua matrícula para recomendações pessoais.");
      }
      const perfilLeitura = perfilDeLeitura(bib);
      const { resultados } = Recomendador.recomendar(bib, perfilLeitura, 12);
      const so = /disponive/.test(q) ? resultados.filter(x => x.livro.disponivel) : resultados;
      if (!so.length) {
        r.texto.push("Ainda não tenho pistas suficientes. Marque alguns livros como lidos ou preencha suas preferências em “Para você”.");
        return r;
      }
      if (usuario) r.texto.push(/disponive/.test(q) ? "Estes combinam com o que você leu e estão disponíveis agora:" : "Separei estes com base no que você leu e nas suas preferências:");
      so.slice(0, 3).forEach(x => r.livros.push({ livro: x.livro, nota: x.motivo }));
      return r;
    }

    // Disponíveis (por gênero)
    if (/disponive|tem algum|o que tem de|quais livros de/.test(q) && (genero || /disponive/.test(q)) && !livro) {
      if (genero) {
        const lista = bib.livros.filter(l => l.genero === genero);
        const disp = lista.filter(l => l.disponivel);
        r.texto.push(disp.length
          ? `Temos ${disp.length} livro(s) de ${genero.toLowerCase()} disponível(is) agora (de ${lista.length} no acervo):`
          : `Neste momento todos os ${lista.length} livros de ${genero.toLowerCase()} estão emprestados. Você pode entrar na fila de reserva.`);
        disp.slice(0, 6).forEach(l => r.livros.push({ livro: l, nota: `${l.qtdDisponiveis} exemplar(es) livre(s)` }));
        if (disp.length > 6) r.texto.push(`…e mais ${disp.length - 6}. Use o filtro de gênero no acervo para ver todos.`);
        return r;
      }
      const porGenero = GENEROS.map(g => [g, bib.livros.filter(l => l.genero === g && l.disponivel).length]).filter(x => x[1]);
      r.texto.push(`Há ${bib.livros.filter(l => l.disponivel).length} títulos com exemplar disponível: ` + porGenero.map(([g, n]) => `${g} (${n})`).join(", ") + ".");
      return r;
    }

    if (livro) {
      r.texto.push(`${livro.titulo}, de ${livro.autor} (${livro.genero.toLowerCase()}, ${livro.paginas || "?"} páginas): ${this.statusLivro(bib, livro, usuario && usuario.id)}`);
      if (livro.sinopse) r.texto.push(livro.sinopse);
      r.livros.push({ livro });
      return r;
    }

    const autor = this.autorMencionado(bib, q);
    if (autor) {
      const dele = bib.livros.filter(l => l.autor === autor);
      r.texto.push(`Temos ${dele.length} livro(s) de ${autor}:`);
      dele.forEach(l => r.livros.push({ livro: l, nota: l.disponivel ? "disponível" : "emprestado" }));
      return r;
    }

    // Último recurso: busca por significado no catálogo
    const busca = BuscaSemantica.buscar(bib, pergunta, { limite: 3 });
    if (!BuscaSemantica.vazia(busca.interpretacao) && busca.resultados.length) {
      const it = busca.interpretacao;
      const partes = [];
      if (it.temas.length) partes.push("temas: " + juntarLista(it.temas));
      if (it.generos.length) partes.push("gênero: " + it.generos.join(", ").toLowerCase());
      if (it.tamanho) partes.push(NOME_TAMANHO[it.tamanho]);
      r.texto.push(`Entendi que você procura ${partes.join(" · ") || "algo assim"}. Encontrei no acervo:`);
      busca.resultados.forEach(x => r.livros.push({ livro: x.livro, nota: x.motivos.join(" · ") }));
      return r;
    }

    r.texto.push("Não encontrei isso nos dados da biblioteca e prefiro não inventar. 😅 Posso ajudar com disponibilidade de livros, prazos dos seus empréstimos, reservas, renovação, multas ou sugestões de leitura.");
    r.sugestoes = this.sugestoesIniciais(perfil);
    r.fonte = false;
    return r;
  }
};
